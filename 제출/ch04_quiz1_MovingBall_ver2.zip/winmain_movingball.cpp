#include<windows.h>

#define X_MIN 50
#define Y_MIN 50
#define X_MAX 400
#define Y_MAX 300
#define DIAMETER 30
#define TIME_RATE 10

enum MOVE_DIR
{
	MOVE_DIR_BOTTOM_RIGHT = 0,
	MOVE_DIR_BOTTOM_LEFT,
	MOVE_DIR_TOP_RIGHT,
	MOVE_DIR_TOP_LEFT = 3,
};

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void CALLBACK TimeProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Moving ball");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

MOVE_DIR eBallDirection = MOVE_DIR_BOTTOM_RIGHT;
RECT rt = { X_MIN,Y_MIN, X_MAX,Y_MAX };
int iX = rt.left;
int iY = rt.top;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	SYSTEMTIME st;

	switch (iMessage)
	{
	case WM_CREATE:
		SetTimer(hWnd, 11, TIME_RATE, TimeProc);
		//SendMessage(hWnd, WM_TIMER, 1, 0);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		Ellipse(hdc, iX, iY, iX + DIAMETER, iY + DIAMETER);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void CALLBACK TimeProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	switch (eBallDirection)
	{
	case MOVE_DIR_BOTTOM_RIGHT:
		iX++;
		iY++;
		if (iX + DIAMETER >= rt.right)
			eBallDirection = MOVE_DIR_BOTTOM_LEFT;
		if (iY + DIAMETER >= rt.bottom)
			eBallDirection = MOVE_DIR_TOP_RIGHT;
		break;
	case MOVE_DIR_BOTTOM_LEFT:
		iX--;
		iY++;
		if (iX <= rt.left)
			eBallDirection = MOVE_DIR_BOTTOM_RIGHT;
		if (iY + DIAMETER >= rt.bottom)
			eBallDirection = MOVE_DIR_TOP_LEFT;
		break;
	case MOVE_DIR_TOP_RIGHT:
		iX++;
		iY--;
		if (iX + DIAMETER >= rt.right)
			eBallDirection = MOVE_DIR_TOP_LEFT;
		if (iY <= rt.top)
			eBallDirection = MOVE_DIR_BOTTOM_RIGHT;
		break;
	case MOVE_DIR_TOP_LEFT:
		iX--;
		iY--;
		if (iX <= rt.left)
			eBallDirection = MOVE_DIR_TOP_RIGHT;
		if (iY <= rt.top)
			eBallDirection = MOVE_DIR_BOTTOM_LEFT;
		break;
	default:
		break;
	}
	InvalidateRect(hWnd, NULL, TRUE);
}