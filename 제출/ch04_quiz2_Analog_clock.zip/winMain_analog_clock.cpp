#include<windows.h>
#include <math.h>
#include <iostream>
#include <string>

using namespace std;
#define RADIUS 200
#define CENTER_X RADIUS+50
#define CENTER_Y CENTER_X
#define LEN_HOUR RADIUS*0.5
#define LEN_MINUE RADIUS*0.8
#define LEN_SECOND RADIUS*0.95
#define LEN_TIME_NUMBER RADIUS*0.95
#define PI 3.14

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Timer");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

void DrawClock(HDC hdc,int Hour, int Minute,int Second)
{
	static TCHAR tmpTime[2];
	Ellipse(hdc, CENTER_X-RADIUS, CENTER_Y - RADIUS, CENTER_X + RADIUS, CENTER_Y + RADIUS);
	for (int iDeg = 1; iDeg <= 12; iDeg++)
	{
		wsprintf(tmpTime, TEXT("%d"), iDeg);
		if (iDeg <= 3 || iDeg>=9)
		{
			SetTextAlign(hdc, TA_BOTTOM | TA_CENTER);
			TextOut(hdc, CENTER_X + LEN_TIME_NUMBER * sin((double)iDeg * 30 * PI / 180), CENTER_Y - LEN_TIME_NUMBER * cos((double)iDeg * 30 * PI / 180), tmpTime, lstrlen(tmpTime));
		}
		else if (iDeg > 3 && iDeg < 9)
		{
			SetTextAlign(hdc, TA_TOP | TA_CENTER);
			TextOut(hdc, CENTER_X + LEN_TIME_NUMBER * sin((double)iDeg * 30 * PI / 180), CENTER_Y - LEN_TIME_NUMBER * cos((double)iDeg * 30 * PI / 180), tmpTime, lstrlen(tmpTime));
		}
	}
	//Hour
	MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	LineTo(hdc, CENTER_X + LEN_HOUR * sin(((double)(Hour%12) * 30 + Minute * 0.5 + Second/120)* PI / 180), CENTER_Y - LEN_HOUR * cos(((double)(Hour % 12) * 30 + Minute * 0.5 + Second / 120)* PI / 180));
	//Minute
	MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	LineTo(hdc, CENTER_X + LEN_MINUE * sin(((double)Minute * 6 + Second*0.1) * PI / 180), CENTER_Y - LEN_MINUE * cos(((double)Minute * 6 + Second * 0.1) * PI / 180));
	//Second
	MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	LineTo(hdc, CENTER_X + LEN_SECOND * sin((double)Second * 6 * PI / 180), CENTER_Y - LEN_SECOND * cos((double)Second * 6 * PI / 180));

	////Hour
	//MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	//LineTo(hdc, CENTER_X + LEN_HOUR * sin((double)(Hour % 12) * 30 * PI / 180), CENTER_Y - LEN_HOUR * cos((double)(Hour % 12) * 30 * PI / 180));
	////Minute
	//MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	//LineTo(hdc, CENTER_X + LEN_MINUE * sin((double)Minute * 6 * PI / 180), CENTER_Y - LEN_MINUE * cos((double)Minute * 6 * PI / 180));
	////Second
	//MoveToEx(hdc, CENTER_X, CENTER_Y, NULL);
	//LineTo(hdc, CENTER_X + LEN_SECOND * sin((double)Second*6*PI/180), CENTER_Y - LEN_SECOND *cos((double)Second * 6 * PI / 180));
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	SYSTEMTIME st;
	static TCHAR sTime[128];
	static int iHour, iMinute, iSecond;
	switch (iMessage)
	{
	case WM_CREATE:
		SetTimer(hWnd, 1, 1000, NULL);
		SendMessage(hWnd, WM_TIMER, 1, 0);
		return 0;
	case WM_TIMER:
		GetLocalTime(&st);
		iHour = st.wHour;
		iMinute = st.wMinute;
		iSecond = st.wSecond;
		wsprintf(sTime, TEXT("[%d : %d : %d]"), iHour, iMinute, iSecond);
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		SetTextAlign(hdc, TA_CENTER);
		TextOut(hdc, CENTER_X, 10, sTime, lstrlen(sTime));
		DrawClock(hdc, iHour, iMinute, iSecond);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}