#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include "Board.h"
#include "Player.h"
class GameManager
{
private:
	Board m_board;
	Player m_player[2];
	int m_iTurn;
	int m_iSelectedPieceNum;
	int m_iLastMovePieceNum;
	POINT m_pointSelectedPiece;

public:
	void Init(HWND hWnd);
	void DrawChessBoard(HDC hdc);
	void DrawPlayerPiece(HDC hdc);
	bool SelectPlayerPiece(HWND hWnd, LPARAM lParam);
	void MovePlayerPiece(HWND hWnd, LPARAM lParam);
	void DropPlayerPiece(HWND hWnd, LPARAM lParam);
	int CheckDropPossible(POINT mousePt, int piece_index, int player,int mode=PLAY_DROP);
	bool CheckPoint(RECT* rect,POINT point);
	bool CheckPawnMove(int move_dir, int mode, int player);
	int CheckGameEnd();
	bool FindCheck(int index);
	bool FindCheckMate();
	int CheckAllPiece(RECT* pRect, int piece_num, int player,int search_mode = SELF);
	void CatchPiece(int index);
	void AlarmPromotion(HWND hWnd, int piece_type);
	int CheckEnPassant(int player_color, int dir_selected);
};

