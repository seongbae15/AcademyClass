#include "Board.h"

void Board::InitBoard(HWND hWnd)
{
	HDC hdc = GetDC(hWnd);
	m_BoardBitmap[WHITE].Init(hdc,TEXT("ResChess//block02.bmp"));
	m_BoardBitmap[BLACK].Init(hdc, TEXT("ResChess//block01.bmp"));
	ReleaseDC(hWnd, hdc);
	m_ImgSize = m_BoardBitmap[BLACK].GetSize();
}

void Board::DrawRect(HDC hdc, int x, int y, int width, int height)
{
	Rectangle(hdc, x, y, x+width, y+height);
}

void Board::DrawOutBox(HDC hdc)
{
	HPEN MyPen, OldPen;
	MyPen = CreatePen(PS_SOLID, 5, RGB(0, 0, 0));
	OldPen = (HPEN)SelectObject(hdc, MyPen);
	DrawRect(hdc, START_X - 3, START_Y - 3,
		m_ImgSize.cx * IMG_RATE * 8 + 6, m_ImgSize.cy * IMG_RATE * 8 + 6);
	SelectObject(hdc, OldPen);
	DeleteObject(MyPen);
}

void Board::DrawBoard(HDC hdc)
{
	int iColor = WHITE;
	//�ֿܰ� �簢�� �׸���//
	DrawOutBox(hdc);
	//ü���� �׸���
	for (int r = 1; r <= ROW; r++)
	{
		for (int c = 1; c <= COL; c++)
		{
			//m_BoardBitmap[iColor % 2].Draw(hdc, m_ImgSize.cx * c * m_fRate, m_ImgSize.cy * r * m_fRate, m_fRate, m_fRate);
			if (iColor % 2 == WHITE)
			{
				HPEN MyPen, OldPen;
				MyPen = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
				OldPen = (HPEN)SelectObject(hdc, MyPen);
				DrawRect(hdc, m_ImgSize.cx * c * IMG_RATE, m_ImgSize.cy * r * IMG_RATE,
					m_ImgSize.cx * IMG_RATE, m_ImgSize.cy * IMG_RATE);
				SelectObject(hdc, OldPen);
				DeleteObject(MyPen);
			}
			else
				m_BoardBitmap[iColor % 2].Draw(hdc, m_ImgSize.cx * c * IMG_RATE, m_ImgSize.cy * r * IMG_RATE, IMG_RATE, IMG_RATE);
			iColor++;
		}
		iColor++;
	}
	//1~8,a~h �ؽ�Ʈ ǥ��
	DrawSideText(hdc);

}

void Board::DrawSideText(HDC hdc)
{
	char chColText = 'A';
	char chRowText = '8';
	TCHAR buf[2];
	SetTextAlign(hdc, TA_CENTER);
	for (int c = 1; c <= COL; c++)
	{
		wsprintf(buf, "%c", chColText);
		TextOut(hdc, m_ImgSize.cx * c * IMG_RATE + m_ImgSize.cx * IMG_RATE * 0.5f, m_ImgSize.cy * IMG_RATE - 25, buf, 1);
		chColText++;
	}
	SetTextAlign(hdc, TA_CENTER);
	for (int r = 1; r <= ROW; r++)
	{
		wsprintf(buf, "%c", chRowText);
		TextOut(hdc, m_ImgSize.cx * IMG_RATE - 20, m_ImgSize.cy * IMG_RATE * r + m_ImgSize.cy * IMG_RATE * 0.5f - 5, buf, 1);
		chRowText--;
	}
}