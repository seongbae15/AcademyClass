#pragma once
#include "PlayLib.h"
#include "BitMap.h"

enum MOVE_STATE
{
	MOVE_STATE_MOVE = 0,
	MOVE_STATE_JUMP,
	MOVE_STATE_MOVING_JUMP,
};

enum DIRECTION
{
	DIRECTION_START = 0,
	DIRECTION_DOWN = 0,
	DIRECTION_UP,
	DIRECTION_LEFT,
	DIRECTION_RIGHT,
	DIRECTION_END = 3,
};

typedef struct CharacterInfo
{
	int iX;
	int iY;
	int iJumpInitX;
	int iJumpInitY;
	int iStep;
	DIRECTION eDir;
	MOVE_STATE eMove;
	MOVE_STATE eLastMove;
};

class Character
{
private:
	BitMap m_bitmap;
	CharacterInfo m_stInfo;
public:
	void InitCharacter(HWND hWnd);
	void DrawCharacter(HDC hdc);
	void MoveCharacter(int move_dir, int move_state = MOVE_STATE_MOVE);
	bool JumpCharacter(int move_state, int loop_count);
	void StopCharacter();
	inline DIRECTION GetDirection()
	{
		return m_stInfo.eDir;
	}
	inline MOVE_STATE GetMoveState()
	{
		return m_stInfo.eMove;
	}
};

