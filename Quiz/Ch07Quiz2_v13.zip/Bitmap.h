#pragma once
#include "PlayLib.h"
#pragma comment (lib,"Msimg32.lib")

class Bitmap
{
private:
	HDC     MemDC;
	HBITMAP m_BitMap;
	HBITMAP m_OldBitMap;
	SIZE    m_size;
public:
	void Init(HDC hdc, LPCSTR FileName);
	void Draw(HDC hdc, int x, int y, float spX=1.0f, float spY=1.0f, int mode=TRANSPARENT);
	inline SIZE GetSize()
	{
		return m_size;
	}
	Bitmap();
	~Bitmap();
};

