#include "Player.h"

void Player::InitEachPiece(HWND hWnd, int player_type, int piece_type)
{
	Piece* tmpPiece = NULL;
	switch ((PIECE_TYPE)piece_type)
	{
	case PIECE_TYPE_PAWN:
		tmpPiece = new Pawn;
		break;
	case PIECE_TYPE_KNIGHT:
		tmpPiece = new Knight;
		break;
	case PIECE_TYPE_BISHOP:
		tmpPiece = new Bishop;
		break;
	case PIECE_TYPE_ROOK:
		tmpPiece = new Rook;
		break;
	case PIECE_TYPE_QUEEN:
		tmpPiece = new Queen;
		break;
	case PIECE_TYPE_KING:
		tmpPiece = new King;
		break;
	}
	tmpPiece->InitPiece(hWnd, player_type, piece_type);
	tmpPiece->SetInitEachPos(player_type, m_iInitPieceCount);
	m_vecPiece.push_back(tmpPiece);
}

void Player::InitPlayer(HWND hWnd, int Player)
{
	m_iInitPieceCount = 0;
	m_iColor = Player;
	for (int i = PIECE_TYPE_PAWN;i <= PIECE_TYPE_KING;)
	{
		InitEachPiece(hWnd, Player, i);
		m_iInitPieceCount++;
		if (i == PIECE_TYPE_PAWN)
		{
			if (m_iInitPieceCount == INIT_PAWN_COUNT)
			{
				i++;
				m_iInitPieceCount = 0;
			}
		}
		else if (i <= PIECE_TYPE_ROOK)
		{
			if (m_iInitPieceCount == INIT_KBR_COUNT)
			{
				i++;
				m_iInitPieceCount = 0;
			}
		}
		else
		{
			i++;
			m_iInitPieceCount = 0;
		}
	}
}

void Player::DrawAllPiece(HDC hdc)
{
	for (int i = 0;i < m_vecPiece.size();i++)
	{
		m_vecPiece[i]->DrawPiece(hdc);
	}
}

void Player::SelectPlayerPiece(int index)
{
	m_vecPiece[index]->SelectPiece();
}

void Player::MovePiece(int index,POINT mousePt)
{
	m_vecPiece[index]->Move(mousePt);
}

void Player::DropPiece(int index, POINT mousePt, int player_type, int move_state)
{
	m_vecPiece[index]->Drop(mousePt, player_type, move_state);
}

void Player::CapturedPiece(int index)
{
	m_vecPiece[index]->Captured();
}

std::vector<RECT> Player::GetSelectedAllMove(int index, POINT pt)
{
	std::vector<RECT>* possibleAllRect =GetAllMove(index);
	std::vector<RECT> possibleRectVec;
	for (int i = 0; i < DIR_COUNT; i++)
	{
		int iSize = possibleAllRect[i].size();
		bool bCheckDir = false;
		possibleRectVec.clear();
		for (int j = 0; j < iSize; j++)
		{
			possibleRectVec.push_back(possibleAllRect[i][j]);
			if (PtInRect(&possibleAllRect[i][j], pt))
			{
				bCheckDir = true;
				possibleRectVec.pop_back();
				break;
			}
		}
		if (bCheckDir)
			break;
	}
	return possibleRectVec;
}

void Player::Release()
{
	for (int i = 0; i < m_vecPiece.size(); i++)
	{
		delete m_vecPiece[i];
	}
	m_vecPiece.clear();
}

void Player::PromotionPiece(HWND hWnd, int pawn_num, int change_type)
{
	RECT rectPawn = m_vecPiece[pawn_num]->GetPieceRect();
	m_vecPiece[pawn_num]->Captured();
	Piece* tmpPromotionPiece = NULL;
	switch ((PIECE_TYPE)change_type)
	{
	case PIECE_TYPE_KNIGHT:
		tmpPromotionPiece = new Knight;
		break;
	case PIECE_TYPE_BISHOP:
		tmpPromotionPiece = new Bishop;
		break;
	case PIECE_TYPE_ROOK:
		tmpPromotionPiece = new Rook;
		break;
	case PIECE_TYPE_QUEEN:
		tmpPromotionPiece = new Queen;
		break;
	}
	tmpPromotionPiece->InitPiece(hWnd, m_iColor, change_type);
	tmpPromotionPiece->SetPromotion(m_iColor, rectPawn);
	m_vecPiece.push_back(tmpPromotionPiece);
}

void Player::ChangeFirstPieceMove(int index)
{
	if (m_vecPiece[index]->GetFirstMoveState() == true)
		m_vecPiece[index]->ChangeFirstMoveState();
}