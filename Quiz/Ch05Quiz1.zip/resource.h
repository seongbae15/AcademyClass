//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Ch05Quiz1.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDB_BITMAP1                     101
#define IDB_BITMAP2                     102
#define IDB_BITMAP3                     103
#define IDB_BITMAP4                     104
#define IDB_BITMAP5                     105
#define IDB_BITMAP6                     106
#define IDB_BITMAP7                     107
#define IDB_BITMAP8                     108
#define IDB_BITMAP9                     109
#define IDB_BITMAP10                    110
#define IDB_BITMAP11                    111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
