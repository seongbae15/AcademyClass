#include<windows.h>
#include "resource.h"

#define IMG_WIDTH 145
#define IMG_HEIGHT 235
#define START_X 20
#define START_Y 20
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Timer");

typedef struct ImageInfo
{
	int iX;
	int iY;
	bool bImgState;
	LPCTSTR lpStrName;
};

enum IMG_LIST
{
	IMG_LIST1 = 101,
	IMG_LIST2,
	IMG_LIST3,
	IMG_LIST4,
	IMG_LIST5,
	IMG_LIST6,
	IMG_LIST7,
	IMG_LIST8,
	IMG_LIST9,
	IMG_LIST10,
};

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

//��������
ImageInfo stImgInfoList[10];
IMG_LIST eImgListNumber;
int iMouseX;
int iMouseY;
const int iImgNumberFirst = IDB_BITMAP1;
void DrawImg(HDC hdc)
{
	HDC MemDC;
	HBITMAP myBitmap[10], oldBitmap;
	MemDC = CreateCompatibleDC(hdc);
	for (int i = 0; i < 10; i++)
	{
		if(stImgInfoList[i].bImgState == true)
			myBitmap[i] = LoadBitmap(g_hInst, MAKEINTRESOURCE(iImgNumberFirst+i));
		else
			myBitmap[i] = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP11));
		oldBitmap = (HBITMAP)SelectObject(MemDC, myBitmap[i]);

		if (i < 5)
			BitBlt(hdc, stImgInfoList[i].iX, stImgInfoList[i].iY, IMG_WIDTH, IMG_HEIGHT, MemDC, 0, 0, SRCCOPY);
		else
			BitBlt(hdc, stImgInfoList[i].iX, stImgInfoList[i].iY, 145, 235, MemDC, 0, 0, SRCCOPY);
		SelectObject(MemDC, oldBitmap);
		DeleteObject(myBitmap[i]);
	}
}

void SetImgInfo()
{
	for (int i = 0; i < 10; i++)
	{
		stImgInfoList[i].bImgState == false;
		if (i < 5)
		{
			stImgInfoList[i].iX = START_X + (IMG_WIDTH + 20) * i;
			stImgInfoList[i].iY = START_Y;
		}
		else
		{
			stImgInfoList[i].iX = START_X + (IMG_WIDTH + 20) * (i - 5);
			stImgInfoList[i].iY = START_Y + (IMG_HEIGHT + 20);
		}
		switch ((IMG_LIST)(iImgNumberFirst + i))
		{
		case IMG_LIST1:
			stImgInfoList[i].lpStrName = TEXT("������");
			break;
		case IMG_LIST2:
			stImgInfoList[i].lpStrName = TEXT("ȣ����");
			break;
		case IMG_LIST3:
			stImgInfoList[i].lpStrName = TEXT("����");
			break;
		case IMG_LIST4:
			stImgInfoList[i].lpStrName = TEXT("�ڳ���");
			break;
		case IMG_LIST5:
			stImgInfoList[i].lpStrName = TEXT("��");
			break;
		case IMG_LIST6:
			stImgInfoList[i].lpStrName = TEXT("��");
			break;
		case IMG_LIST7:
			stImgInfoList[i].lpStrName = TEXT("������");
			break;
		case IMG_LIST8:
			stImgInfoList[i].lpStrName = TEXT("������");
			break;
		case IMG_LIST9:
			stImgInfoList[i].lpStrName = TEXT("������");
			break;
		case IMG_LIST10:
			stImgInfoList[i].lpStrName = TEXT("��");
			break;
		default:
			break;
		}
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	switch (iMessage)
	{
	case WM_CREATE:
		SetImgInfo();
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		DrawImg(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_LBUTTONDOWN:
		iMouseX = LOWORD(lParam);
		iMouseY = HIWORD(lParam);
		for (int i = 0; i < 10; i++)
		{
			if ((iMouseX >= stImgInfoList[i].iX && iMouseX <= stImgInfoList[i].iX + IMG_WIDTH)
				&& (iMouseY >= stImgInfoList[i].iY && iMouseY <= stImgInfoList[i].iY + IMG_HEIGHT))
			{
				if (stImgInfoList[i].bImgState == false)
					stImgInfoList[i].bImgState = true;
				InvalidateRect(hWnd, NULL, TRUE);
				MessageBox(hWnd, stImgInfoList[i].lpStrName, TEXT("Animal Box:"), MB_OK);
			}
		}
		return 0;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
