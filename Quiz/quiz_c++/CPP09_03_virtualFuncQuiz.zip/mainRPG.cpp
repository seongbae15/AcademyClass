#include "GameManager.h"
#include <iostream>

void main()
{
	GameManager GM;
	GM.RunGame();
}