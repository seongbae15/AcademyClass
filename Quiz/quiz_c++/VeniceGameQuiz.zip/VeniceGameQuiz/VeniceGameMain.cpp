#include "Play.h"

void main()
{
	Play mainPlay;
	mainPlay.GameOn();
}