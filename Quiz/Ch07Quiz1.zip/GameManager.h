#pragma once
#include <vector>
#include "BitMap.h"
#include "Character.h"



class GameManager
{
private:
	Character m_character;
	bool m_bMoveTimer;
	bool m_bJumpTimer;
	DIRECTION m_ePdir;
	MOVE_STATE m_ePmoveState;
	int m_iJumpLoopCount;
	std::vector<int> m_vecKeyBuf;
public:
	void Init(HWND hWnd);
	void Draw(HWND hWnd, HDC hdc);
	void Move(HWND hWnd, WPARAM move_dir);
	void Jump(HWND hWnd);
	void Stop(HWND hWnd);
	void AddKeyBuffer(WPARAM move_dir);
	void EraseKeyBuffer(WPARAM move_dir);
	inline MOVE_STATE GetMoveState()
	{
		return m_ePmoveState;
	}
	inline int GetSizeKeyBuffer()
	{
		return m_vecKeyBuf.size();
	}
	inline int GetLastKeyBuffer()
	{
		return m_vecKeyBuf.back();
	}
};

