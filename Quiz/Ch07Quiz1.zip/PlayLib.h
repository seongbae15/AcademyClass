#pragma once

#define WIN_WIDTH 600
#define WIN_HEIGHT 600

#define MAX_STEP 3

#define MOVE_STEP 5

#define ACC_G 10
#define VEL_UP 20
#define JUMP_DISTANCE 20
#define MAX_JUMP_COUNT 41

#define JUMP_TIME 1