#include "Character.h"

void Character::Init(HDC hdc)
{
	char chBuf[256];
	wsprintf(chBuf, "Circus\\player0.bmp");
	m_character[STEP_STOP].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\player1.bmp");
	m_character[STEP_WALK].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\player2.bmp");
	m_character[STEP_GALLOP].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\die.bmp");
	m_character[STEP_DIE].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\win.bmp");
	m_character[CH_VIC1].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\win2.bmp");
	m_character[CH_VIC2].InitSet(hdc, TEXT(chBuf));

	m_iStep = STEP_STOP;
	m_bMoveTime = false;
	m_bJumpTime = false;

	m_iPosX = CH_POS_X;
	m_iPosY = CH_JUMP_MIN_POS;
	m_iJumpCount = 1;
	m_bLiveState = true;
	m_iLife = 3;
	m_bVictoryState = false;
}

void Character::Draw(HDC hdc)
{
	if (m_bVictoryState == true)
	{
		m_character[m_iStep].DrawImg(hdc, m_iPosX, CH_POS_Y + m_iPosY, 1.0f, 1.0f, DRAW_MODE_TB);
	}
	else
	{
		if (m_bLiveState == true)
			m_character[m_iStep].DrawImg(hdc, m_iPosX, CH_POS_Y + m_iPosY, 1.0f, 1.0f, DRAW_MODE_TB);
		else
			m_character[STEP_DIE].DrawImg(hdc, m_iPosX, CH_POS_Y + m_iPosY, 1.0f, 1.0f, DRAW_MODE_TB);
	}
}

void Character::Move(HWND hWnd, WPARAM wParam)
{
	//�ٸ� Ű�Է� ���·� ������ �� ����
	if (m_bMoveTime == false && m_bJumpTime == false)
	{
		switch (wParam)
		{
		case VK_LEFT:
		case VK_RIGHT:
			m_bMoveTime = true;
			m_iStep++;
			break;
		}
		SetTimer(hWnd, TIMER_CH_MOVE, TIME_CHARACTER_MOVE, NULL);
	}
	else
	{
		if (wParam == TIMER_CH_MOVE)
		{
			if (m_iStep == STEP_GALLOP)
			{
				m_iStep = STEP_STOP;
				m_bMoveTime = false;
				KillTimer(hWnd, TIMER_CH_MOVE);
			}
			else
				m_iStep++;
		}
	}
}

void Character::MoveX(WPARAM wParam)
{
	if (m_bVictoryState == false)
	{
		switch (wParam)
		{
		case VK_LEFT:
			m_iPosX -= BACK_IMG_MOVE;
			break;
		case VK_RIGHT:
			m_iPosX += BACK_IMG_MOVE;
			break;
		}
	}
}

bool Character::JumpCharacter(HWND hWnd, WPARAM wParam)
{
	if (m_bJumpTime == false)
	{
		m_bJumpTime = true;
		m_iStep = STEP_GALLOP;
		SetTimer(hWnd, TIMER_CH_MOVE, TIME_CHARACTER_MOVE, NULL);
	}
	else
	{
		if (m_iJumpCount == JUMP_MAX_COUNT)
		{
			m_iStep = STEP_STOP;
			m_iJumpCount = 1;
			m_bJumpTime = false;
			m_bMoveTime = false;
			KillTimer(hWnd, TIMER_CH_MOVE);
			return false;
		}
		else
		{
			if (wParam == TIMER_CH_MOVE)
			{
				//character pos y
				m_iPosY = -JUMP_INIT_VELY * m_iJumpCount + HALF_G * m_iJumpCount * m_iJumpCount;
				m_iJumpCount++;
			}
		}
	}
}

void Character::Victory(HWND hWnd)
{
	m_bVictoryState = true;
	//Kill ���� �� ���� Ÿ�̸�
	KillTimer(hWnd, TIMER_CH_MOVE);
	//��ġ �̵�(���� ��ġ ���� �ö� ���� �̵�)
	if (m_iPosX < CH_GOAL_POS_X)
		m_iPosX++;
	else if (m_iPosX > CH_GOAL_POS_X)
		m_iPosX--;
	// ��� ����
	if (m_iStep != CH_VIC1)
		m_iStep = CH_VIC1;
	else
		m_iStep = CH_VIC2;
}

void Character::Respawn()
{
	m_iStep = STEP_STOP;
	m_bLiveState = true;
}