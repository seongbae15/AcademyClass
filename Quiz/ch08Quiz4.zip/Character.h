#pragma once
#include "Bitmap.h"

class Character
{
private:
	Bitmap m_character[6];
	int m_iStep;
	bool m_bMoveTime;
	bool m_bJumpTime;
	int m_iPosX;
	int m_iPosY;
	int m_iJumpCount;
	bool m_bLiveState;
	int m_iLife;
	bool m_bVictoryState;

public:
	void Init(HDC hdc);
	void Draw(HDC hdc);
	void Move(HWND hWnd, WPARAM wParam);
	void MoveX(WPARAM wParam);
	bool JumpCharacter(HWND hWnd, WPARAM wParam);
	void Victory(HWND hWnd);
	void Respawn();
	void ChangeCharacterState()
	{
		m_bLiveState = false;
	}
	int GetStep()
	{
		return m_iStep;
	}
	RECT GetCharacterRect()
	{
		return { m_iPosX,CH_POS_Y+m_iPosY,m_iPosX + m_character[0].GetSize().cx,CH_POS_Y+ m_iPosY + m_character[0].GetSize().cy };
	}
	bool GetLiveState()
	{
		return m_bLiveState;
	}
	int GetChPosX()
	{
		return m_iPosX;
	}
};