#pragma once
#include "Bitmap.h"
class Obstacle
{
private:
protected:
	WPARAM m_wKey;
	int m_iFrame;
	int m_iPosX;
	int m_iPosY;

public:
	virtual void Init(HDC hdc) = 0;
	virtual void Draw(HDC hdc, int mode = 0) = 0;
	virtual void Move(WPARAM wParam) = 0;
	void ChangeImg();
	virtual RECT GetObstacleRect(int index) = 0;

};

class FireLamp : public Obstacle
{
private:
	Bitmap m_obstacle[2];
	bool m_bArrScoredState[LAMP_MAX_COUNT];
public:
	void Init(HDC hdc);
	void Draw(HDC hdc,int mode = BACK_FIRE);
	void Move(WPARAM wParam);
	void ChangeScoredState(int index);

	RECT GetObstacleRect(int index)
	{
		return { m_iPosX+ FIRE_RECT_X_ADJ , m_iPosY, m_iPosX + m_obstacle[0].GetSize().cx- FIRE_RECT_X_ADJ
			,m_iPosY + m_obstacle[0].GetSize().cy };
	}
	bool GetScoredState(int index)
	{
		return m_bArrScoredState[index];
	}

};
class FireRing : public Obstacle
{
private:
	Bitmap m_fObstacle[2];
	Bitmap m_bObstacle[2];
	Bitmap m_fObsWmoney;
	Bitmap m_bObsWmoney;
	int m_iArrIndexShape[3];
	bool m_bArrScoredState[3];
public:
	void Init(HDC hdc);
	void Draw(HDC hdc, int mode = BACK_FIRE);
	void Move(WPARAM wParam);
	void ChangeScoredState(int index);

	RECT GetObstacleRect(int index)
	{
		if(m_iArrIndexShape[index] < RAND_PROB)
			return { m_iPosX+10 , m_iPosY + m_fObstacle[0].GetSize().cy-10, m_iPosX + m_bObstacle[0].GetSize().cx-10,m_iPosY + m_bObstacle[0].GetSize().cy };
		else
			return { m_iPosX + 10 , m_iPosY + m_fObsWmoney.GetSize().cy - 10, m_iPosX + m_fObsWmoney.GetSize().cx - 10,m_iPosY + m_bObsWmoney.GetSize().cy };
	}
	int GetRingType(int index)
	{
		return m_iArrIndexShape[index];
	}
	bool GetScoredState(int index)
	{
		return m_bArrScoredState[index];
	}

};

