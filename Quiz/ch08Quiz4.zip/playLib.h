#pragma once
#include <Windows.h>
#include <time.h>

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

#define BACK_IMG_LOOP 11
#define BACK_IMG_MOVE 2

#define CH_POS_X 65
#define CH_POS_Y 315

#define METER_DISTANCE 500
#define METER_POS_X CH_POS_X-15
#define METER_POS_Y CH_POS_Y+70

#define METER_TEXT_ADD_X 20
#define METER_TEXT_Y METER_POS_Y+7

#define DRAW_MODE_BB 0
#define DRAW_MODE_SB 1
#define DRAW_MODE_TB 2

#define STEP_STOP 0
#define STEP_WALK 1
#define STEP_GALLOP 2
#define STEP_DIE 3
#define CH_VIC1 4
#define CH_VIC2 5

#define VICTORY1 0
#define VICTORY2 1

#define TIMER_KEY_IN 1
#define TIMER_CH_MOVE 2
#define TIMER_OBS_CHANGE 3
#define TIMER_GAME_CLEAR 4
#define TIMER_GAME_RESPAWN 5
#define TIMER_BONUS 6

#define JUMP_MAX_COUNT 10
#define JUMP_INIT_VELY 45
#define HALF_G 5

#define TIME_CHARACTER_MOVE 150
#define TIME_BACK_IMG_MOVE TIME_CHARACTER_MOVE/15
#define TIME_OBS_CHANGE 500
#define TIME_CLEAR_MOVE 150
#define TIME_RESPAWN 1500
#define TIME_BONUS_SCORE 200


#define COE_MOVE 3

#define RING_MAX_COUNT 3
#define LAMP_MAX_COUNT 9

#define RAND_TOTAL_PROB 100
#define RAND_PROB 60

#define CH_MAX_STEP 2
#define CH_JUMP_MIN_POS 0
#define CH_JUMP_MAX_POS -100

#define CH_MOVE 1
#define CH_NO_MOVE 0

#define FIRE_L_INIT_X 1000
#define FIRE_L_INIT_Y 330
#define FIRE_R_INIT_X 700
#define FIRE_R_INIT_Y 197

#define FIRE_RECT_X_ADJ 15

#define BACK_FIRE 0
#define FRONT_FIRE 1

#define KEYIN_TRUE 0x8000

#define MAX_METER 11

#define MAX_DISTANCE_FRAME 4550

#define GOAL_INIT_POS_X 1000
#define GOAL_POS_X 500
#define GOAL_POS_Y 330

#define CH_GOAL_POS_X GOAL_POS_X+5
#define CH_GOAL_POS_Y GOAL_POS_Y-5

#define INIT_LIFE 3

#define INIT_BONUS 5000
#define BONUS_DEC 10

#define CRUSH_OVER 0
#define CRUSH_NONE 1
#define CRUSH_SCORE 2

#define SCORE_LAMP 200
#define SCORE_RING 100
#define SCORE_RING_MONEY 1000