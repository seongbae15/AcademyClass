#pragma once
#include "playLib.h"
#pragma comment (lib,"Msimg32.lib")

class Bitmap
{
private:
	HDC m_MemDC;
	HBITMAP m_BitMap;
	HBITMAP m_OldBitMap;
	SIZE    m_size;
public:
	void InitSet(HDC hdc, LPCSTR FileName = NULL);
	void DrawImg(HDC hdc, int x, int y, float spX = 1.0f, float spY = 1.0f, int mode=0);
	
	inline SIZE GetSize()
	{
		return m_size;
	}
	inline HDC getMemDC()
	{
		return m_MemDC;
	}
	Bitmap();
	~Bitmap();
};

