#pragma once
#include "Bitmap.h"
class GameUI
{
private:
	Bitmap m_chIcon;
	int m_iScore;
	int m_iBonus;
	HPEN m_myPen;
	HPEN m_myPen2;
	HPEN m_oldPen;
	HPEN m_oldPen2;
	HBRUSH m_myBrush;
	HBRUSH m_oldBrush;

public:
	void Init(HDC hdc);
	void Draw(HDC hdc, int life_count);
	void DrawBox(HDC hdc);
	void UpdateScore(int addScore);
	void UpdateBonusScore();
	int GetBonus()
	{
		return m_iBonus;
	}
};

