#pragma once
#include "playLib.h"
#include "Bitmap.h"
#include "BackImg.h"
#include "Character.h"
#include "Obstacle.h"
#include "GameUI.h"
#include <time.h>
class GameFrame
{
private:
	Bitmap m_backPallet;
	HDC m_backPalletMemHdc;
	Bitmap m_backBlack;
	BackImg m_backImg;
	Character m_characterImg;
	FireLamp m_fireLampImg;
	FireRing m_fireRingImg;
	GameUI m_gameUI;

	WPARAM m_wDirection;
	int m_iOldBackImgTime;
	int m_iCurBackImgTime;
	int m_iOldFireImgTime;
	int m_iCurFireImgTime;
	bool m_bJumpState;
	int m_iFrameMove;
	bool m_bGameOver;
	bool m_bGameClear;
	bool m_bGameScore;
	int m_iPlayerLife;
	bool m_bCheckerRing;
	bool m_bCheckerRingMoney;
	bool m_bCheckerLamp;
	int m_iLampIndex;
	int m_iRingIndex;

public:
	void Init(HWND hWnd);
	void Update(HWND hWnd, HDC hdc);
	void DrawUpdate(HDC hdc);
	void UpdateMove(HWND hWnd, WPARAM wParam);
	WPARAM CheckKeyInput();
	void ChangeObsShape();
	int CheckCrush();
	int CheckImgIntersect(RECT* rect1, RECT* rect2);
	bool CheckGameClear();
	void GameClear(HWND hWnd);
	void GameRespawn();
	void UpdateBonus();
	bool CheckUpdateScore(RECT* rect1, RECT* rect2);
	void ScoreUp();
	void GameEndMessage(HWND hWnd);

};