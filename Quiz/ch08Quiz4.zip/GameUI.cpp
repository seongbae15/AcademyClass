#include "GameUI.h"

void GameUI::Init(HDC hdc)
{
	char chBuf[256];
	wsprintf(chBuf, "Circus\\icon.bmp");
	m_chIcon.InitSet(hdc,chBuf);
	m_iScore = 0;
	m_iBonus = INIT_BONUS;

}

void GameUI::Draw(HDC hdc, int life_count)
{
	char chBuf[256];
	//Box �׸���
	DrawBox(hdc);
	//Score �׸���
	wsprintf(chBuf, "1P - %06d",m_iScore);
	TextOut(hdc, 170, 50, chBuf,11);

	wsprintf(chBuf, "BONUS - %04d", m_iBonus);
	TextOut(hdc, 170, 70, chBuf, 12);

	//Icon �׸���(���� �ϴ�)
	for (int i = 0; i < life_count; i++)
		m_chIcon.DrawImg(hdc, 400 + 20 * i, 70, 1.0f, 1.0f, DRAW_MODE_TB);
}

void GameUI::DrawBox(HDC hdc)
{
	////��� ������, �׵θ�, ���� �� �Ķ��� �簢�� 2�� �׸���
	m_myPen = CreatePen(PS_SOLID, 5, RGB(0, 0, 255));
	m_myPen2 = CreatePen(PS_SOLID, 3, RGB(255, 0, 0));
	m_myBrush = CreateSolidBrush(RGB(0, 0, 0));
	m_oldBrush = (HBRUSH)SelectObject(hdc, m_myBrush);
	m_oldPen = (HPEN)SelectObject(hdc, m_myPen);
	Rectangle(hdc, 145, 20, WINDOW_WIDTH - 150, 110);
	SelectObject(hdc, m_oldPen);
	DeleteObject(m_myPen);
	m_oldPen2 = (HPEN)SelectObject(hdc, m_myPen2);
	Rectangle(hdc, 155, 30, WINDOW_WIDTH - 160, 100);
	SelectObject(hdc, m_oldPen2);
	DeleteObject(m_myPen2);
	
	SelectObject(hdc, m_oldBrush);
	DeleteObject(m_myBrush);

}

void GameUI::UpdateScore(int addScore)
{
	m_iScore += addScore;
}

void GameUI::UpdateBonusScore()
{
	//���ʽ� ������Ʈ
	if (m_iBonus >= 0)
	{
		m_iBonus -= BONUS_DEC;
	}
	else
		m_iBonus;
}