#pragma once
#include "Bitmap.h"
#include <vector>

class BackImg
{
private:
	Bitmap m_back;
	
	Bitmap m_backNormal[2];
	int m_iVic;

	Bitmap m_backDeco;
	std::vector<Bitmap> m_vecBackImgList;
	int m_iMovePosX;
	WPARAM m_wKey;
	int m_iBackImgCount;

	Bitmap m_backMeter;
	int m_iMeterX;

	Bitmap m_backGoal;
	int m_iGoalX;

public:
	void Init(HDC hdc);
	void Draw(HDC hdc);
	WPARAM Move(WPARAM wParam);
	void UpdateBackImgCount();
	void Victory(HWND hWnd);
	RECT GetRectGoal()
	{
		return { m_iMeterX + METER_DISTANCE * (MAX_METER - 1),  GOAL_POS_Y,
			m_iMeterX + METER_DISTANCE * (MAX_METER - 1) + m_backGoal.GetSize().cx,
			GOAL_POS_Y + m_backGoal.GetSize().cy };
	}
};

