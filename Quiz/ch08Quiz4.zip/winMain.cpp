/* ��Ŀ�� ���� �����
---------------------------------------------------------------------
  + UI ǥ��(ȭ��, ������ ��)
    - ������
	- �簢�� �ٹ̱�
*/

#include <Windows.h>
#include "GameFrame.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void CALLBACK TimeProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Circus Charlie");

GameFrame g_gameFrame;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,
		NULL, (HMENU)NULL, hInstance, NULL);

	srand(time(NULL));

	ShowWindow(hWnd, nCmdShow);

	HDC hdc;
	hdc = GetDC(hWnd);
	while (true)
	{
		if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			if (Message.message == WM_QUIT)
				break;
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
		else
		{
			g_gameFrame.Update(hWnd, hdc);
		}
	}
	ReleaseDC(hWnd, hdc);
	return (int)Message.wParam;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	static bool bKeyDown = false;
	switch (iMessage)
	{
	case WM_CREATE:
		g_gameFrame.Init(hWnd);
		SetTimer(hWnd, TIMER_KEY_IN, 1, TimeProc);
		SetTimer(hWnd, TIMER_OBS_CHANGE, TIME_OBS_CHANGE, NULL);
		SetTimer(hWnd, TIMER_BONUS, TIME_BONUS_SCORE, NULL);
		return 0;
	case WM_TIMER:
		switch (wParam)
		{
		case TIMER_CH_MOVE:
			g_gameFrame.UpdateMove(hWnd, wParam);
			break;
		case TIMER_OBS_CHANGE:
			g_gameFrame.ChangeObsShape();
			break;
		case TIMER_GAME_CLEAR:
			g_gameFrame.GameClear(hWnd);
			break;
		case TIMER_GAME_RESPAWN:
			g_gameFrame.GameRespawn();
			KillTimer(hWnd, TIMER_GAME_RESPAWN);
			break;
		case TIMER_BONUS:
			g_gameFrame.UpdateBonus();
			break;
		}
		return 0;
	case WM_DESTROY:
		KillTimer(hWnd, TIMER_KEY_IN);
		KillTimer(hWnd, TIMER_CH_MOVE);
		KillTimer(hWnd, TIMER_OBS_CHANGE);
		KillTimer(hWnd, TIMER_GAME_CLEAR);
		KillTimer(hWnd, TIMER_GAME_RESPAWN);
		KillTimer(hWnd, TIMER_BONUS);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void CALLBACK TimeProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	WPARAM tempWparam = g_gameFrame.CheckKeyInput();
	g_gameFrame.UpdateMove(hWnd, tempWparam);
}