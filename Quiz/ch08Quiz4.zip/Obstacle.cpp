#include "Obstacle.h"

void Obstacle::ChangeImg()
{
	if (m_iFrame == 1)
		m_iFrame = 0;
	else
		m_iFrame++;
}

void FireLamp::Init(HDC hdc)
{
	char chBuf[256];
	wsprintf(chBuf, "Circus\\front.bmp");
	m_obstacle[0].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\front2.bmp");
	m_obstacle[1].InitSet(hdc, TEXT(chBuf));

	m_iFrame = 0;
	m_iPosX = FIRE_L_INIT_X;
	m_iPosY = FIRE_L_INIT_Y;
	m_wKey = 0;
	for (int i = 0; i < LAMP_MAX_COUNT; i++)
		m_bArrScoredState[i] = false;
}

void FireLamp::Draw(HDC hdc, int mode)
{
	for (int i = 0; i < LAMP_MAX_COUNT; i++)
	{
		m_obstacle[m_iFrame].DrawImg(hdc, m_iPosX + METER_DISTANCE *i, m_iPosY, 1, 1, DRAW_MODE_TB);
	}
}

void FireLamp::Move(WPARAM wParam)
{
	WPARAM tmpWparam;
	if (wParam == TIMER_CH_MOVE)
		tmpWparam = m_wKey;
	else
	{
		m_wKey = wParam;
		tmpWparam = m_wKey;
	}
	switch (tmpWparam)
	{
	case VK_LEFT:
		m_iPosX += BACK_IMG_MOVE;
		break;
	case VK_RIGHT:
		m_iPosX -= BACK_IMG_MOVE;
		break;
	}
}

void FireLamp::ChangeScoredState(int index)
{
	if (m_bArrScoredState[index] == false)
		m_bArrScoredState[index] = true;
}


void FireRing::Init(HDC hdc)
{
	char chBuf[256];
	wsprintf(chBuf, "Circus\\enemy_b.bmp");
	m_bObstacle[0].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\enemy_1b.bmp");
	m_bObstacle[1].InitSet(hdc, TEXT(chBuf));

	wsprintf(chBuf, "Circus\\enemy_f.bmp");
	m_fObstacle[0].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\enemy_1f.bmp");
	m_fObstacle[1].InitSet(hdc, TEXT(chBuf));

	wsprintf(chBuf, "Circus\\enemy_l_b.bmp");
	m_bObsWmoney.InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\enemy_l_f.bmp");
	m_fObsWmoney.InitSet(hdc, TEXT(chBuf));

	m_iFrame = 0;
	m_iPosX = FIRE_R_INIT_X;
	m_iPosY = FIRE_R_INIT_Y;
	m_wKey = 0;

	for (int i = 0; i < RING_MAX_COUNT; i++)
	{
		m_iArrIndexShape[i] = rand() % RAND_TOTAL_PROB;
		m_bArrScoredState[i] = false;
	}
}

void FireRing::Draw(HDC hdc, int mode)
{
	for (int i = 0; i < RING_MAX_COUNT; i++)
	{
		switch (mode)
		{
		case BACK_FIRE:
			if(m_iArrIndexShape[i]< RAND_PROB)
				m_bObstacle[m_iFrame].DrawImg(hdc, m_iPosX + METER_DISTANCE * i, m_iPosY, 1, 1, DRAW_MODE_TB);
			else
				m_bObsWmoney.DrawImg(hdc, m_iPosX + METER_DISTANCE * i, m_iPosY, 1, 1, DRAW_MODE_TB);
			break;
		case FRONT_FIRE:
			if (m_iArrIndexShape[i] < RAND_PROB)
			{
				int iTempX = m_bObstacle[m_iFrame].GetSize().cx;
				m_fObstacle[m_iFrame].DrawImg(hdc, m_iPosX + METER_DISTANCE * i + iTempX, m_iPosY, 1, 1, DRAW_MODE_TB);
			}
			else
			{
				int iTempX = m_bObsWmoney.GetSize().cx;
				m_fObsWmoney.DrawImg(hdc, m_iPosX + METER_DISTANCE * i + iTempX, m_iPosY, 1, 1, DRAW_MODE_TB);
			}
			break;
		}
	}
}

void FireRing::Move(WPARAM wParam)
{
	switch (wParam)
	{
	case VK_LEFT:
		m_iPosX += BACK_IMG_MOVE;
		break;
	case VK_RIGHT:
		m_iPosX -= COE_MOVE *BACK_IMG_MOVE;
		break;
	default:
		m_iPosX -= BACK_IMG_MOVE;
		break;
	}
	if (m_iPosX <= CH_POS_X - METER_DISTANCE)
	{
		m_iPosX += METER_DISTANCE;
		for (int i = 0; i < RING_MAX_COUNT - 1; i++)
		{
			m_iArrIndexShape[i] = m_iArrIndexShape[i + 1];
			m_bArrScoredState[i] = m_bArrScoredState[i + 1];
		}
		m_iArrIndexShape[RING_MAX_COUNT-1] = rand() % RAND_TOTAL_PROB;
		m_bArrScoredState[RING_MAX_COUNT - 1] = false;
	}
}

void FireRing::ChangeScoredState(int index)
{
	if (m_bArrScoredState[index] == false)
		m_bArrScoredState[index] = true;

}