#include "BackImg.h"

void BackImg::Init(HDC hdc)
{
	char chBuf[256];

	//�׶��� ��Ʈ�� �ʱ�ȭ
	wsprintf(chBuf, "Circus\\back.bmp");
	m_back.InitSet(hdc, TEXT(chBuf));

	//���� �ʱ�ȭ
	wsprintf(chBuf, "Circus\\back_normal.bmp");
	m_backNormal[0].InitSet(hdc, TEXT(chBuf));
	wsprintf(chBuf, "Circus\\back_normal2.bmp");
	m_backNormal[1].InitSet(hdc, TEXT(chBuf));
	m_iVic = 0;

	//�ڸ��� �׸� �ʱ�ȭ(Deco)
	wsprintf(chBuf, "Circus\\back_deco.bmp");
	m_backDeco.InitSet(hdc, TEXT(chBuf));

	m_iMovePosX = 0;
	m_iBackImgCount = BACK_IMG_LOOP;

	//���ͱ� �ʱ�ȭ
	wsprintf(chBuf, "Circus\\meter.bmp");
	m_backMeter.InitSet(hdc, TEXT(chBuf));
	m_iMeterX = METER_POS_X;
	SetTextColor(hdc, RGB(255, 255, 255));
	SetBkColor(hdc, RGB(0, 0, 0));

	//���� ��ġ �̹��� �ʱ�ȭ
	wsprintf(chBuf, "Circus\\end.bmp");
	m_backGoal.InitSet(hdc, TEXT(chBuf));
	m_iGoalX = GOAL_INIT_POS_X;

}

void BackImg::Draw(HDC hdc)
{
	SIZE sizeBackNormal = m_backNormal[m_iVic].GetSize();
	for (int i = -1; i < BACK_IMG_LOOP; i++)
	{
		if (i == m_iBackImgCount - 1)
			m_backDeco.DrawImg(hdc, sizeBackNormal.cx * i - m_iMovePosX, 200 - sizeBackNormal.cy - 2);
		else
		{
			if(m_iVic == VICTORY1)
				m_backNormal[m_iVic].DrawImg(hdc, sizeBackNormal.cx * i - m_iMovePosX, 200 - sizeBackNormal.cy);
			else
				m_backNormal[m_iVic].DrawImg(hdc, sizeBackNormal.cx * i - m_iMovePosX-1, 200 - sizeBackNormal.cy + 2);
		}
	}
	m_back.DrawImg(hdc, 0, 200, BACK_IMG_LOOP, 1.0f, 1);
	//Text ǥ�� & Meter ǥ��
	for (int i = 0; i < MAX_METER; i++)
	{
		m_backMeter.DrawImg(hdc, m_iMeterX + METER_DISTANCE * i, METER_POS_Y, 1.0f, 1.0f, DRAW_MODE_TB);
		char chBuf[256];
		wsprintf(chBuf, "%d", 100 - 10 * i);
		if (i == 0)
			TextOut(hdc, m_iMeterX + METER_TEXT_ADD_X + METER_DISTANCE * i, METER_TEXT_Y, chBuf, 3);
		else if (i == MAX_METER - 1)
		{
			TextOut(hdc, m_iMeterX + METER_TEXT_ADD_X + METER_DISTANCE * i, METER_TEXT_Y, chBuf, 1);
			m_backGoal.DrawImg(hdc, m_iMeterX + METER_DISTANCE * i, GOAL_POS_Y, 1.0f, 1.0f, DRAW_MODE_TB);
		}
		else
			TextOut(hdc, m_iMeterX + METER_TEXT_ADD_X + METER_DISTANCE * i, METER_TEXT_Y, chBuf, 2);
	}
}

void BackImg::UpdateBackImgCount()
{
	//��� ��ġ ī��� ������Ʈ
	if (m_iMovePosX >= m_backNormal[m_iVic].GetSize().cx)
	{
		m_iMovePosX = 0;
		if (m_iBackImgCount == 0)
			m_iBackImgCount = BACK_IMG_LOOP;
		else
			m_iBackImgCount--;
	}
	else if (m_iMovePosX <= -m_backNormal[m_iVic].GetSize().cx)
	{
		m_iMovePosX = 0;
		if (m_iBackImgCount == BACK_IMG_LOOP)
			m_iBackImgCount = 0;
		else
			m_iBackImgCount++;
	}
}

WPARAM BackImg::Move(WPARAM wParam)
{
	WPARAM tmpWparam;
	if (wParam == TIMER_CH_MOVE)
		tmpWparam = m_wKey;
	else
	{
		m_wKey = wParam;
		tmpWparam = m_wKey;
	}
	switch (tmpWparam)
	{
	case VK_LEFT:
		m_iMovePosX -= BACK_IMG_MOVE;
		m_iMeterX += BACK_IMG_MOVE;
		break;
	case VK_RIGHT:
		m_iMovePosX += BACK_IMG_MOVE;
		m_iMeterX -= BACK_IMG_MOVE;
		break;
	}
	//��� ��ġ ī��� ������Ʈ
	UpdateBackImgCount();
	return m_wKey;
}

void BackImg::Victory(HWND hWnd)
{
	if (m_iVic != VICTORY1)
		m_iVic = VICTORY1;
	else
		m_iVic = VICTORY2;
}