#include "BitMap.h"

BitMap::BitMap()
{
}

void BitMap::Init(HDC hdc, LPCTSTR FileName)
{
	m_MemDC = CreateCompatibleDC(hdc);
	m_pBitMap = (HBITMAP)LoadImage(NULL, FileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	m_pBitOld = (HBITMAP)SelectObject(m_MemDC, m_pBitMap);

	BITMAP BitMap_Info;
	GetObject(m_pBitMap, sizeof(BitMap_Info), &BitMap_Info);
	m_Size.cx = (BitMap_Info.bmWidth)/4;
	m_Size.cy = (BitMap_Info.bmHeight)/4;
}

void BitMap::Draw(HDC hdc, int x, int y, int step, int direction, float spX, float spY)
{
	//BitBlt(hdc, 50, 50, x, y, m_MemDC, 0, 0, SRCCOPY);
	//StretchBlt(hdc, x, y, m_Size.cx * spX, m_Size.cy * spY, m_MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
	TransparentBlt(hdc, x, y, m_Size.cx * spX, m_Size.cy * spY, m_MemDC, m_Size.cx * step, m_Size.cy* direction, m_Size.cx, m_Size.cy, RGB(255, 0, 255));
}

BitMap::~BitMap()
{
}
