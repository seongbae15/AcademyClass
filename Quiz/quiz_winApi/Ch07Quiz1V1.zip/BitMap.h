#pragma once
#include <Windows.h>
#pragma comment (lib,"Msimg32.lib")
class BitMap
{
private:
	HDC m_MemDC;
	HBITMAP m_pBitMap;
	HBITMAP m_pBitOld;
	SIZE m_Size;
public:
	BitMap();
	void Init(HDC hdc, LPCTSTR FileName);
	void Draw(HDC hdc, int x, int y, int step, int direction, float spX=1, float spY=1);
	~BitMap();
	inline SIZE GetImgSize()
	{
		return m_Size;
	}
};

