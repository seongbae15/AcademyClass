#include <Windows.h>
#include <time.h>
#define CIRCLE 0
#define RECTANGLE 1
#define FIGURE_SIZE_X 100
#define FIGURE_SIZE_Y 100
#define WINDOW_WIDTH 1024
#define WINDOW_HEIGHT 768
#define SCREEN_X 800
#define SCREEN_Y 600

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void CALLBACK TimeProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);
void DrawFigure(HWND hWnd, int x, int y);
void ChangeFigure();
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("CharacterMove");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	////���� �ڵ�
	//while (GetMessage(&Message, NULL, 0, 0))
	//{
	//	TranslateMessage(&Message);
	//	DispatchMessage(&Message);
	//}

	srand(time(NULL));
	HDC hdc;
	hdc = GetDC(hWnd);
	while (true)
	{
		if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			if (Message.message == WM_QUIT)
				break;
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
		else
			SetPixel(hdc, rand() % SCREEN_X, rand() % SCREEN_Y, RGB(rand()% 256, rand() % 256, rand() % 256));
	}
	ReleaseDC(hWnd, hdc);

	return (int)Message.wParam;
}

static int g_iShape = CIRCLE;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	
	switch (iMessage)
	{
	case WM_KEYDOWN:
		if (wParam == VK_SPACE)
		{
			int iX = rand() % (SCREEN_X - FIGURE_SIZE_X);
			int iY = rand() % (SCREEN_Y - FIGURE_SIZE_Y);
			//Draw Figure
			DrawFigure(hWnd, iX,iY);
		}
		else if (wParam == VK_RETURN)
			//Change Figure
			ChangeFigure();
		else if (wParam == VK_ESCAPE)
		{
			g_iShape = CIRCLE;
			//ȭ�� �ʱ�ȭ
			InvalidateRect(hWnd, NULL, TRUE);
		}
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0); 
		return 0;
	} 
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void DrawFigure(HWND hWnd, int x, int y)
{
	HDC hdc = GetDC(hWnd);
	HBRUSH MyBrush, OldBrush;
	//���� ����
	MyBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
	OldBrush = (HBRUSH)SelectObject(hdc, MyBrush);
	//�׸��� ��ġ ����
	if (g_iShape == CIRCLE)
		Ellipse(hdc, x, y, x + FIGURE_SIZE_X, y + FIGURE_SIZE_Y);
	else if (g_iShape == RECTANGLE)
		Rectangle(hdc, x, y, x + FIGURE_SIZE_X, y + FIGURE_SIZE_Y);
	SelectObject(hdc, OldBrush);
	DeleteObject(MyBrush);
}

void ChangeFigure()
{
	if (g_iShape == CIRCLE)
		g_iShape = RECTANGLE;
	else if (g_iShape == RECTANGLE)
		g_iShape = CIRCLE;
}