#include "Piece.h"

void Piece::DrawPiece(HDC hdc)
{
	if (m_bLive == true)
	{
		m_pieceBitmap.Draw(hdc, m_stPos.iX, m_stPos.iY, IMG_RATE, IMG_RATE);
	}
}

RECT Piece::SetImgRect(int x, int y)
{
	RECT rectXY = { x ,y ,(int)(x + m_sizePieceImg.cx * IMG_RATE),(int)(y + m_sizePieceImg.cy * IMG_RATE) };
	return rectXY;
}

void Piece::SelectPiece()
{
	m_stLastPos = m_stPos;
}

void Piece::Move(POINT mousePt)
{
	m_stPos.iX = mousePt.x - m_sizePieceImg.cx * IMG_RATE * 0.5f;
	m_stPos.iY = mousePt.y - m_sizePieceImg.cy * IMG_RATE * 0.5f;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
}

void Piece::Drop(POINT mousePt, int player_type, int move_state)
{
	if (move_state != DROP_FALSE)
	{
		int iTmpX = (mousePt.x - START_X) / (m_sizePieceImg.cx * IMG_RATE);
		int iTmpY = (mousePt.y - START_Y) / (m_sizePieceImg.cy * IMG_RATE);
		m_stPos.iX = START_X + m_sizePieceImg.cx * IMG_RATE * iTmpX;
		m_stPos.iY = START_Y + m_sizePieceImg.cy * IMG_RATE * iTmpY;
		//m_stLastPos = m_stPos;
		//m_bFirstMove = false;
	}
	else
		m_stPos = m_stLastPos;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
}

void Piece::ChangeInfo(int player_type)
{
	if (m_bFirstMove)
		m_bFirstMove = false;
	SetPossibleMove(player_type);
}

void Piece::Captured()
{
	m_bLive = false;
}

void Piece::SetPromotion(int player_type,RECT rectPawn)
{
	m_rectPiece = rectPawn;
	m_stPos.iX = rectPawn.left;
	m_stPos.iY = rectPawn.top;
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Piece::TakeBack(int player_type)
{
	m_stPos = m_stLastPos;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	SetPossibleMove(player_type);
}

void Pawn::InitPiece(HWND hWnd,int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_00.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_bFirstMove = true;
	m_iPieceType = piece_type;
	m_strPieceType = "Pawn";
	
}

void Pawn::SetInitEachPos(int player_type, int pieceCount)
{
	m_stPos.iX = START_X + pieceCount * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 6 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 1 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Pawn::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		RECT tmpRect;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			if (player_type == WHITE)
			{
				if (stTmpPos.iY > START_Y)
				{
					stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
					if (m_bFirstMove == true)
					{
						stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
						tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
						m_vecRectPossibleMove2[i].push_back(tmpRect);
					}
				}
			}
			break;
		case MOVE_DIR_TOP_LEFT:
			if (player_type == WHITE)
			{
				if (stTmpPos.iX > START_X && stTmpPos.iY > START_Y)
				{
					stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
					stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
				}
			}
			break;
		case MOVE_DIR_LEFT:
			break;
		case MOVE_DIR_DOWN_LEFT:
			if (player_type == BLACK)
			{
				if (stTmpPos.iX > START_X && stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
				{
					stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
					stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
				}
			}
			break;
		case MOVE_DIR_DOWN:
			if (player_type == BLACK)
			{
				if (stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
				{
					stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
					if (m_bFirstMove == true)
					{
						stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
						tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
						m_vecRectPossibleMove2[i].push_back(tmpRect);
					}
				}
			}
			break;
		case MOVE_DIR_DOWN_RIGHT:
			if (player_type == BLACK)
			{
				if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
					&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
				{
					stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
					stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
				}
			}
			break;
		case MOVE_DIR_RIGHT:
			break;
		case MOVE_DIR_TOP_RIGHT:
			if (player_type == WHITE)
			{
				if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
					&& stTmpPos.iY > START_Y)
				{
					stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
					stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
					tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
					m_vecRectPossibleMove2[i].push_back(tmpRect);
				}
			}
			break;
		}
	}
}

void Knight::InitPiece(HWND hWnd, int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_01.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);
	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_iPieceType = piece_type;
	m_strPieceType = "Knight";
}

void Knight::SetInitEachPos(int player_type, int pieceCount)
{
	m_stPos.iX = START_X + (5 * pieceCount + 1) * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Knight::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		RECT tmpRect;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			if (stTmpPos.iX > START_X && stTmpPos.iY > START_Y + m_sizePieceImg.cy * IMG_RATE)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE * 2;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_LEFT:
			if (stTmpPos.iX > START_X + m_sizePieceImg.cx * IMG_RATE && stTmpPos.iY > START_Y)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE * 2;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_LEFT:
			if (stTmpPos.iX > START_X + m_sizePieceImg.cx * IMG_RATE
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE * 2;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_LEFT:
			if (stTmpPos.iX > START_X
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 6)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE * 2;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 6)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE * 2;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 6
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE * 2;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 6
				&& stTmpPos.iY > START_Y)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE * 2;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY > START_Y + m_sizePieceImg.cy * IMG_RATE)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE * 2;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		}
	}
}

void Bishop::InitPiece(HWND hWnd, int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_02.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);
	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_iPieceType = piece_type;
	m_strPieceType = "Bishop";
}

void Bishop::SetInitEachPos(int player_type, int pieceCount)
{
	m_stPos.iX = START_X + (3 * pieceCount + 2) * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Bishop::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		RECT tmpRect;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			break;
		case MOVE_DIR_TOP_LEFT:
			while (stTmpPos.iX > START_X && stTmpPos.iY > START_Y)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_LEFT:
			break;
		case MOVE_DIR_DOWN_LEFT:
			while (stTmpPos.iX > START_X && stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN:
			break;
		case MOVE_DIR_DOWN_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_RIGHT:
			break;
		case MOVE_DIR_TOP_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY > START_Y)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		}
	}
}


void Rook::InitPiece(HWND hWnd, int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_03.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_bFirstMove = true;
	m_iPieceType = piece_type;
	m_strPieceType = "Rook";
}

void Rook::SetInitEachPos(int player_type, int pieceCount)
{
	m_stPos.iX = START_X + (7 * pieceCount) * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Rook::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		RECT tmpRect;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			while (stTmpPos.iY > START_Y)
			{
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_LEFT:
			break;
		case MOVE_DIR_LEFT:
			while (stTmpPos.iX > START_X)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_LEFT:
			break;
		case MOVE_DIR_DOWN:
			while (stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_RIGHT:
			break;
		case MOVE_DIR_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_RIGHT:
			break;
		}
	}
}

void Queen::InitPiece(HWND hWnd, int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_04.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_iPieceType = piece_type;
	m_strPieceType = "Queen";

}

void Queen::SetInitEachPos(int player_type, int pieceCount)
{
	m_stPos.iX = START_X + (pieceCount + 3) * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void Queen::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		RECT tmpRect;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			while (stTmpPos.iY > START_Y)
			{
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_LEFT:
			while (stTmpPos.iX > START_X && stTmpPos.iY > START_Y)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_LEFT:
			while (stTmpPos.iX > START_X)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_LEFT:
			while (stTmpPos.iX > START_X && stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN:
			while (stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_RIGHT:
			while (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY > START_Y)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		}
	}
}

void King::InitPiece(HWND hWnd, int player_type, int piece_type)
{
	char chBuf[256];
	char chPlayer;
	if (player_type == WHITE)
		chPlayer = 'w';
	else if (player_type == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_05.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_bFirstMove = true;
	m_iPieceType = piece_type;
	m_strPieceType = "King";

}

void King::SetInitEachPos(int player_type,int pieceCount)
{
	m_stPos.iX = START_X + (pieceCount + 4) * m_sizePieceImg.cx * IMG_RATE;
	if (player_type == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (player_type == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	m_rectPiece = SetImgRect(m_stPos.iX, m_stPos.iY);
	m_stLastPos = m_stPos;
	SetPossibleMove(player_type);
}

void King::SetPossibleMove(int player_type)
{
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!m_vecRectPossibleMove2[i].empty())
			m_vecRectPossibleMove2[i].clear();
		Position stTmpPos;
		RECT tmpRect;
		stTmpPos.iX = m_stPos.iX;
		stTmpPos.iY = m_stPos.iY;
		switch ((MOVE_DIR)i)
		{
		case MOVE_DIR_TOP:
			if (stTmpPos.iY > START_Y)
			{
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_LEFT:
			if (stTmpPos.iX > START_X && stTmpPos.iY > START_Y)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_LEFT:
			if (stTmpPos.iX > START_X)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_LEFT:
			if (stTmpPos.iX > START_X && stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX -= m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN:
			if (stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_DOWN_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY < START_Y + m_sizePieceImg.cy * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY += m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);
			}
			break;
		case MOVE_DIR_TOP_RIGHT:
			if (stTmpPos.iX < START_X + m_sizePieceImg.cx * IMG_RATE * 7
				&& stTmpPos.iY > START_Y)
			{
				stTmpPos.iX += m_sizePieceImg.cx * IMG_RATE;
				stTmpPos.iY -= m_sizePieceImg.cy * IMG_RATE;
				tmpRect = SetImgRect(stTmpPos.iX, stTmpPos.iY);
				m_vecRectPossibleMove2[i].push_back(tmpRect);

			}
			break;
		}
	}
}