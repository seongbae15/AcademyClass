#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include <vector>
#include <string>

enum PIECE_TYPE
{
	PIECE_TYPE_PAWN =0,
	PIECE_TYPE_KNIGHT,
	PIECE_TYPE_BISHOP,
	PIECE_TYPE_ROOK,
	PIECE_TYPE_QUEEN,
	PIECE_TYPE_KING,
};

enum MOVE_DIR
{
	MOVE_DIR_START = 0,
	MOVE_DIR_TOP = 0,
	MOVE_DIR_TOP_LEFT,
	MOVE_DIR_LEFT,
	MOVE_DIR_DOWN_LEFT,
	MOVE_DIR_DOWN,
	MOVE_DIR_DOWN_RIGHT,
	MOVE_DIR_RIGHT,
	MOVE_DIR_TOP_RIGHT,
	MOVE_DIR_END,
};

struct Position
{
	int iX;
	int iY;
};

class Piece
{
protected:
	bool m_bLive;
	Bitmap m_pieceBitmap;
	SIZE m_sizePieceImg;
	Position m_stPos;
	Position m_stLastPos;
	RECT m_rectPiece;
	bool m_bFirstMove;
	int m_iPieceType;
	std::vector<RECT> m_vecRectPossibleMove2[DIR_COUNT];
	std::string m_strPieceType;

public:
	virtual void InitPiece(HWND hWnd, int player_type, int piece_type) = 0;
	virtual void SetInitEachPos(int player_type, int pieceCount) = 0;
	void DrawPiece(HDC hdc);
	void SelectPiece();
	void Move(POINT mousePt);
	RECT SetImgRect(int x, int y);
	void Drop(POINT mousePt, int player_type, int move_state = true);
	virtual void SetPossibleMove(int player = WHITE) = 0;
	void Captured();
	void SetPromotion(int player_type, RECT rectPawn);
	void TakeBack(int player_type);
	void ChangeInfo(int player_type);
	inline RECT GetPieceRect()
	{
		if (m_bLive == true)
			return m_rectPiece;
		else
			return { -75,-75,-150,-150 };
	}
	inline std::vector<RECT>* GetPossibleMoveAll()
	{
		return m_vecRectPossibleMove2;
	}
	inline int GetType()
	{
		return m_iPieceType;
	}
	inline bool GetLiveState()
	{
		return m_bLive;
	}
	inline Position GetCurPosition()
	{
		return m_stPos;
	}
	inline Position GetLastPosition()
	{
		return m_stLastPos;
	}
	inline bool GetFirstMoveState()
	{
		return m_bFirstMove;
	}
};

class Pawn : public Piece
{
private:
	
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};

class Knight : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};

class Bishop : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};

class Rook : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};

class Queen : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};

class King : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player, int piece_type);
	void SetInitEachPos(int player_type, int pieceCount);
	void SetPossibleMove(int player_type);
};