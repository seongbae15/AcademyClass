#pragma once
#include <vector>
#include "BitMap.h"
#include "Character.h"

class GameManager
{
private:
	Character m_character;
	bool m_bMoveTimer;
	bool m_bJumpTimer;
	DIRECTION m_ePdir;
	MOVE_STATE m_ePmoveState;
	int m_iJumpLoopCount;

	std::vector<int> m_vecKeyBuf;
public:
	void Init(HWND hWnd);
	void Draw(HWND hWnd, HDC hdc);
	//GetKeyState���
	void Move2(HWND hWnd, WPARAM move_dir);
	void Jump2(HWND hWnd);
	void MoveEnd(HWND hWNd, WPARAM wParam);
	inline MOVE_STATE GetMoveState()
	{
		return m_ePmoveState;
	}
	inline WPARAM GetLastMove()
	{
		if (!m_vecKeyBuf.empty())
			return (WPARAM)m_vecKeyBuf.back();
		else
			return 0;
	}
};

