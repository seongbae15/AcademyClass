#pragma once

#define WIN_WIDTH 1024
#define WIN_HEIGHT 768

#define MAX_STEP 3

#define MOVE_STEP 5

#define ACC_G 10
#define VEL_UP 20
#define JUMP_DISTANCE 20
#define MAX_JUMP_COUNT 41

#define MOVE_TIME 200
#define NUMBER_MOVE_TIMER 1
#define JUMP_TIME 1

#define MOVING_MIN_X 0
#define MOVING_MIN_Y 0
#define MOVING_MAX_X 1024
#define MOVING_MAX_Y 768
