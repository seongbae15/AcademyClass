#include "GameManager.h"
#include<Windows.h>
#include <stdlib.h>
#include <time.h>

#define FAIL -1
#define WIN_WIDTH 880
#define WIN_HEIGHT 1000

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Animal Card");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	srand((unsigned)time(NULL));
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 0, 0, WIN_WIDTH, WIN_HEIGHT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

//��������
int iMouseX;
int iMouseY;
int iSecond = 0;
TCHAR sTime[128];
bool bClickState = true;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	TCHAR msgBoxText[128];
	static int iCheckFlipNumber = FAIL;
	static int iLastFlipNumber = iCheckFlipNumber;
	int iMinute, iHour;
	int tmpCardCount;
	switch (iMessage)
	{
	case WM_CREATE:
		GameManager::GetInstance()->Init(hWnd, g_hInst);
		iSecond = 0;
		SetTimer(hWnd, 1, 1000, NULL);
		SendMessage(hWnd, WM_TIMER, 1, 0);
	case WM_TIMER:
		iMinute = iSecond/60;
		iHour = iMinute / 60;
		wsprintf(sTime, TEXT("%d:%d:%d"),iHour,iMinute,(iSecond++%60));
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		//Disp Timer
		TextOut(hdc, 350, 1, sTime, lstrlen(sTime));
		//Disp Card
		GameManager::GetInstance()->Draw(hdc);
		EndPaint(hWnd, &ps);
		bClickState = true;
		return 0;
	case WM_LBUTTONDOWN:
		
		if (bClickState)
		{
			iMouseX = LOWORD(lParam);
			iMouseY = HIWORD(lParam);
			iCheckFlipNumber = GameManager::GetInstance()->CheckCardFlip(GetDC(hWnd), g_hInst, iMouseX, iMouseY);
			if (iCheckFlipNumber != FAIL && (GameManager::GetInstance()->GetNthCardState(iCheckFlipNumber) == false))
			{
				//ī�� ������
				GameManager::GetInstance()->CardFlip(g_hInst, iCheckFlipNumber, CARD_FRONT);
				InvalidateRect(hWnd, NULL, TRUE);
				SendMessage(hWnd, WM_PAINT, 0, 0);
				tmpCardCount = GameManager::GetInstance()->GetFlipCardCount();
				if (tmpCardCount != 0 && (tmpCardCount % 2) == 0)
				{
					//Check Same Card
					if (GameManager::GetInstance()->GetNthCardImg(iCheckFlipNumber) != GameManager::GetInstance()->GetNthCardImg(iLastFlipNumber))
					{
						bClickState = false;
						//ī�� �ٽ� ������
						GameManager::GetInstance()->CardFlip(g_hInst, iCheckFlipNumber, CARD_BACK);
						GameManager::GetInstance()->CardFlip(g_hInst, iLastFlipNumber, CARD_BACK);
						Sleep(500);
					}
				}
				iLastFlipNumber = iCheckFlipNumber;
			}
		}
		if (GameManager::GetInstance()->GetFlipCardCount() == MAX_CARD)
		{
			wsprintf(msgBoxText, TEXT("Your Record %d:%d:%d\n Again???"), iSecond /3600, (iSecond/60)%60, (iSecond % 60));
			KillTimer(hWnd, 1);
			if (MessageBox(hWnd, msgBoxText, TEXT("Game End"), MB_YESNO)==IDYES)
				return SendMessage(hWnd, WM_CREATE, 0, 0);
			else
				return SendMessage(hWnd, WM_DESTROY, 0, 0);
		}
		return 0;
	case WM_DESTROY:
		GameManager::GetInstance()->Release();
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
