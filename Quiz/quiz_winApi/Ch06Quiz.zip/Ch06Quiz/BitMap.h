#pragma once
#include <windows.h>
#include "resource.h"

#define CARD_FRONT 0
#define CARD_BACK 1

class BitMap
{
private:
	HDC m_MemDC;
	HBITMAP m_pBitMap;
	HBITMAP m_pBitOld;
	SIZE m_size;
public:
	BitMap();
	void Init(HDC hdc, HINSTANCE hInst, int id);
	void Draw(HDC hdc, int x, int y, float spX =1.0f, float spY = 1.0f);
	void ChangeImg(HINSTANCE hInst,int id,int mode= CARD_FRONT);
	~BitMap();
};

