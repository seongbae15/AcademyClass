#include "BitMap.h"

BitMap::BitMap()
{

}

void BitMap::Init(HDC hdc, HINSTANCE hInst, int id)
{
	m_MemDC = CreateCompatibleDC(hdc);
	m_pBitMap = (HBITMAP)LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP11));
	m_pBitOld = (HBITMAP)SelectObject(m_MemDC, m_pBitMap);
	BITMAP Bitmap_Info;
	GetObject(m_pBitMap, sizeof(Bitmap_Info), &Bitmap_Info);
	m_size.cx = Bitmap_Info.bmWidth;
	m_size.cy = Bitmap_Info.bmHeight;
}

void BitMap::Draw(HDC hdc, int x, int y, float spX, float spY)
{
	StretchBlt(hdc, x, y, m_size.cx * spX, m_size.cy * spY, m_MemDC, 0, 0, m_size.cx, m_size.cy, SRCCOPY);
}

void BitMap::ChangeImg(HINSTANCE hInst, int id, int mode)
{
	if (mode == CARD_FRONT)
	{
		m_pBitMap = (HBITMAP)LoadBitmap(hInst, MAKEINTRESOURCE(id));
		m_pBitOld = (HBITMAP)SelectObject(m_MemDC, m_pBitMap);
	}
	else if (mode == CARD_BACK)
	{
		m_pBitMap = (HBITMAP)LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP11));
		m_pBitOld = (HBITMAP)SelectObject(m_MemDC, m_pBitMap);
	}
}


BitMap::~BitMap()
{
	SelectObject(m_MemDC, m_pBitOld);
	DeleteObject(m_pBitMap);
	DeleteObject(m_MemDC);
}