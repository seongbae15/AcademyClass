#pragma once
#include <Windows.h>
#include <stdlib.h>
#include <vector>
#include "BitMap.h"
#include "resource.h"
#include "Card.h"

#define MAX_CARD 20
#define FIRST_IMG 101

typedef struct CardInfo
{
	Card m_Card;
	BitMap* pBitMap;
}CardInfo;

class GameManager
{
private:
	static GameManager* m_pThis;
	std::vector<CardInfo> m_vecCardList;
	int m_iFlipCardCount;
public:
	static GameManager* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new GameManager;
		return m_pThis;
	}
	GameManager();
	void Init(HWND hWnd, HINSTANCE hInst);
	void Draw(HDC hdc);
	int CheckCardFlip(HDC hdc, HINSTANCE hInst,int mouseX, int mouseY);
	void CardFlip(HINSTANCE hInst, int i, int mode = CARD_FRONT);
	inline LPCTSTR getNthCardName(int i)
	{
		return m_vecCardList[i].m_Card.GetCardName();
	}
	inline int GetNthCardImg(int i)
	{
		return m_vecCardList[i].m_Card.GetCardImgNum();
	}
	inline bool GetNthCardState(int i)
	{
		return m_vecCardList[i].m_Card.GetCardState();
	}
	inline int GetFlipCardCount()
	{
		return m_iFlipCardCount;
	}
	void Release();
	~GameManager();
};

