#include "GameManager.h"

GameManager* GameManager::m_pThis = NULL;

GameManager::GameManager()
{

}

void GameManager::Init(HWND hWnd, HINSTANCE hInst)
{
	m_iFlipCardCount = 0;
	HDC hdc = GetDC(hWnd);
	if (!m_vecCardList.empty())
		m_vecCardList.clear();
	for (int i = 0; i < MAX_CARD; i++)
	{
		CardInfo tmpCardInfo;
		while (1)
		{
			bool bChecker = false;
			int imgNum = rand() % 10 + FIRST_IMG;
			int iSameCardCount = 0;
			if (m_vecCardList.empty());
			else
			{
				for (int j = 0; j < m_vecCardList.size(); j++)
				{
					if (imgNum == m_vecCardList[j].m_Card.GetCardImgNum())
						iSameCardCount++;
					if (iSameCardCount == 2)
					{
						bChecker = true;
						break;
					}
				}
			}
			if (bChecker == false)
			{
				tmpCardInfo.m_Card.SetCard(i, imgNum);
				tmpCardInfo.pBitMap = new BitMap;
				tmpCardInfo.pBitMap->Init(hdc, hInst, imgNum);
				break;
			}
		}
		m_vecCardList.push_back(tmpCardInfo);
	}
}

void GameManager::Draw(HDC hdc)
{
	for (int i = 0; i < MAX_CARD; i++)
	{
		m_vecCardList[i].pBitMap->Draw(hdc, m_vecCardList[i].m_Card.GetPosX(), m_vecCardList[i].m_Card.GetPosY(), IMG_RATE, IMG_RATE);
	}
}

int GameManager::CheckCardFlip(HDC hdc, HINSTANCE hInst,int mouseX, int mouseY)
{
	for (int i = 0; i < MAX_CARD; i++)
	{
		if ((mouseX >= m_vecCardList[i].m_Card.GetPosX() && mouseX <= (m_vecCardList[i].m_Card.GetPosX() + IMG_WIDTH* IMG_RATE))
			&& (mouseY >= m_vecCardList[i].m_Card.GetPosY() && mouseY <= (m_vecCardList[i].m_Card.GetPosY() + IMG_HEIGHT* IMG_RATE)))
			return i;
	}
	return -1;
}

void GameManager::CardFlip(HINSTANCE hInst, int i,int mode)
{
	if (mode == CARD_FRONT)
	{
		m_vecCardList[i].pBitMap->ChangeImg(hInst, m_vecCardList[i].m_Card.GetCardImgNum(), CARD_FRONT);
		m_vecCardList[i].m_Card.FlipCard();
		m_iFlipCardCount++;
	}
	else if (mode == CARD_BACK)
	{
		m_vecCardList[i].pBitMap->ChangeImg(hInst, m_vecCardList[i].m_Card.GetCardImgNum(), CARD_BACK);
		m_vecCardList[i].m_Card.FlipCard();
		m_iFlipCardCount--;
	}
}

void GameManager::Release()
{
	delete(m_pThis);
}

GameManager::~GameManager()
{
	for (int i = 0; i < MAX_CARD; i++)
	{
		delete(m_vecCardList[i].pBitMap);
	}
	m_vecCardList.clear();
}