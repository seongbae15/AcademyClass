#include "SnakeGameManager.h"

void main()
{
	SnakeGameManager SnakeGM;
	SnakeGM.GameRun();
}