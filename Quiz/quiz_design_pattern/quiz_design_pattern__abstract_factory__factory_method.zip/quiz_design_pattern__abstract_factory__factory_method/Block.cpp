#include "Block.h"

void Block::ClearBlock()
{
	m_vecBlockPos.clear();
}
