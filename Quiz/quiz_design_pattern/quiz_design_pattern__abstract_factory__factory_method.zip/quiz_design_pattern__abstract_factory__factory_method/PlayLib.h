#pragma once
#include <conio.h>
#include <string>
#include <stdlib.h>

#define MAP_WIDTH 50
#define MAP_HEIGHT 30
