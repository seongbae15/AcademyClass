#pragma once
#include "ViewFactoryMethod.h"
class GameOverView : public ViewFactoryMethod
{
public:
	void DrawView();
};

