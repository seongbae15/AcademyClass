#include "ViewFactoryMethod.h"
