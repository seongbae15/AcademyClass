#pragma once
#include "ViewFactoryMethod.h"

class PlayView : public ViewFactoryMethod
{
public:
	void DrawView();
};

