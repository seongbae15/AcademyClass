#pragma once
#include "ViewFactoryMethod.h"

class LobyView : public ViewFactoryMethod
{
protected:
public:
	void DrawView();
};

