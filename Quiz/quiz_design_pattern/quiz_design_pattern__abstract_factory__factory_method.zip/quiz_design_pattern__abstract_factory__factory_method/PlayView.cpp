#include "PlayView.h"

void PlayView::DrawView()
{
	m_viewDrawManager.DrawBaseMap(MAP_WIDTH, MAP_HEIGHT);
}
