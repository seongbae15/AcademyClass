#pragma once
#include "PlayLib.h"
#include "Piece.h"

class Player
{
private:
	int m_iColor;
	std::vector<Piece*> m_vecPiece;
	int m_iInitPieceCount;


public:
	void InitPlayer(HWND hWnd, int player_type);
	void InitEachPiece(HWND hWnd, int player_type, int piece_type);
	void DrawAllPiece(HDC hdc);
	void MovePiece(int index, POINT mousePt);
	void DropPiece(int index, POINT mousePt, int player_type, int move_state = DROP_NO_CATCH);
	void CapturedPiece(int index);
	std::vector<RECT> GetSelectedAllMove(int index, POINT pt);
	void Release();
	void PromotionPiece(HWND hWnd, int pawn_num, int change_type);

	inline int GetPieceVecSize()
	{
		return m_vecPiece.size();
	}
	inline RECT GetNthPieceRect(int index)
	{
		return m_vecPiece[index]->GetPieceRect();
	}
	inline std::vector<RECT>* GetAllMove(int index)
	{
		return m_vecPiece[index]->GetPossibleMoveAll();
	}
	inline int GetSelectedPieceType(int index)
	{
		return m_vecPiece[index]->GetType();
	}
	inline bool GetPieceLiveState(int index)
	{
		return m_vecPiece[index]->GetLiveState();
	}
};