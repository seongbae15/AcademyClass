#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_board.InitBoard(hWnd);
	m_player[WHITE].InitPlayer(hWnd,WHITE);
	m_player[BLACK].InitPlayer(hWnd,BLACK);
}

void GameManager::DrawChessBoard(HDC hdc)
{
	m_board.DrawBoard(hdc);
}

void GameManager::DrawPlayerPiece(HDC hdc)
{
	m_player[WHITE].DrawAllPiece(hdc);
	m_player[BLACK].DrawAllPiece(hdc);
}

bool GameManager::SelectPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	
	int iSize = m_player[m_iTurn % 2].GetPieceVecSize();
	for (int i = 0; i < iSize;i++)
	{
		RECT rectSelected = m_player[m_iTurn % 2].GetNthPieceRect(i);
		if (PtInRect(&rectSelected, ptMouse))
		{
			m_iSelectedPieceNum = i;
			InvalidateRect(hWnd, &rectSelected, true);
			return true;
		}
	}
	return false;
}

void GameManager::MovePlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	RECT rectPiece = m_player[m_iTurn % 2].GetNthPieceRect(m_iSelectedPieceNum);
	m_player[m_iTurn % 2].MovePiece(m_iSelectedPieceNum, ptMouse);	
	InvalidateRect(hWnd, &rectPiece, true);
}

bool GameManager::FindCheck(int index)
{
	RECT rectKing = m_player[(m_iTurn + 1) % 2].GetNthPieceRect(KING);
	POINT pointKing = { rectKing.left,rectKing.top };
	int iStateCatchKing = CheckDropPossible(pointKing, index, SELF, PLAY_SEARCH);
	if (iStateCatchKing == DROP_CATCH)
		return true;
	else
		return false;
}


bool GameManager::FindCheckMate()
{
	//üũ����Ʈ ��� ��
	//>>üũ �� �Ҽ� ���� ��,

	//1.���� üũ�ϰ� �ִ� �⹰�� ��´�.
	//1) üũ�� ���� ������ ���� ��,
		//������ �ǽ����� üũ�� ���� ��ġ�� �̵� ������ �ϴٸ�
	RECT rectCheckPiece = m_player[m_iTurn % 2].GetNthPieceRect(m_iSelectedPieceNum);
	POINT pointCheckPiece = { rectCheckPiece.left,rectCheckPiece.top };
	int iPieceCount = m_player[(m_iTurn + 1) % 2].GetPieceVecSize();
	for (int i = 0;i < iPieceCount;i++)
	{
		//�� üũ�� ��, ���� ���� �ȵ� ���¿��� SELF, OTHER
		int iStateCatchCheckPiece = CheckDropPossible(pointCheckPiece, i, OTHER, PLAY_SEARCH);
		if (iStateCatchCheckPiece == DROP_CATCH)
			return false;

		//2.�Ʊ��� �⹰�� ����Ѵ�.
		//  >> ����� �ǽ��� �ش� �ǽ��� �������� �����Ѵ�.
		//    >>> üũ�� ���� �̵��� ��ġ��, �Ʊ��� ���� �̵��Ҽ� �ִ��� Ȯ��
		if (i == KING)
			continue;
		RECT rectKing = m_player[(m_iTurn + 1) % 2].GetNthPieceRect(KING);
		POINT pointKing = { rectKing.left,rectKing.top };
		std::vector<RECT> vecCheckMove = m_player[m_iTurn % 2].GetSelectedAllMove(m_iSelectedPieceNum, pointKing);
		for (int j = 0; j < vecCheckMove.size(); j++)
		{
			POINT ptCheckMove = { vecCheckMove[j].left, vecCheckMove[j].top };
			int iStateDropCheckMove = CheckDropPossible(ptCheckMove, i, OTHER, PLAY_SEARCH);
			if (iStateDropCheckMove == DROP_NO_CATCH)
				return false;
		}
	}
	//3.������ �ް� �ִ� �ڽ��� ŷ�� ������ ��ҷ� �����δ�.
	//>> ŷ�� ������ ��ġ�� �̵��� �� ���� ��
	//  >>> ŷ�� �ش� ��ġ�� ����� �� ���� ��,
	//  >>> ŷ�� �̵��� �Ҽ� �ִ��� �˻�(CATCH or, DROP_NOCATCH)
	//  >>> DROP�� �����ϸ�, �ش� ��ġ�� ���� CHECK�� �Ҽ� �ִ��� �˻�
	std::vector<RECT>* rectKingAllMove = m_player[(m_iTurn + OTHER) % 2].GetAllMove(KING);
	for (int i = 0; i < DIR_COUNT; i++)
	{
		if (!rectKingAllMove[i].empty())
		{
			POINT ptKingMove = { rectKingAllMove[i][0].left,rectKingAllMove[i][0].top };
			int iKingMoveState = CheckDropPossible(ptKingMove, KING, OTHER, PLAY_SEARCH);
			if (iKingMoveState != DROP_FALSE)
			{
				int iOwnPieceCount = m_player[m_iTurn % 2].GetPieceVecSize();
				for (int j = 0; j < iOwnPieceCount; j++)
				{
					int iCheckMoveState = CheckDropPossible(ptKingMove, j, SELF, PLAY_SEARCH);
					if (iCheckMoveState == DROP_NO_CATCH)
						return true;
				}
			}
		}
	}
	return false;
}

int GameManager::CheckGameEnd()
{
	if (FindCheck(m_iSelectedPieceNum))
	{
		if (FindCheckMate())
			return GAME_END_CHECKMATE;
		else
			return GAME_END_CHECK;
	}
	else
		return GAME_END_NONE;
}

void GameManager::AlarmPromotion(HWND hWnd, int piece_type)
{
	char chType[10];
	switch (piece_type)
	{
	case PIECE_TYPE_QUEEN:
		wsprintf(chType, "Queen");
		break;
	case PIECE_TYPE_ROOK:
		wsprintf(chType, "Rook");
		break;
	case PIECE_TYPE_BISHOP:
		wsprintf(chType, "Bishop");
		break;
	case PIECE_TYPE_KNIGHT:
		wsprintf(chType, "Knight");
		break;
	default:
		break;
	}
	char buf[256];
	wsprintf(buf, "Chage : %s", chType);
	if (piece_type <= PIECE_TYPE_KNIGHT)
		MessageBox(hWnd, buf, TEXT("Promotion"), MB_OK);
	else
	{
		int iMsgPromotion = MessageBox(hWnd, buf, TEXT("Promotion"), MB_OKCANCEL);
		if (iMsgPromotion != 1)
		{
			AlarmPromotion(hWnd, --piece_type);
			return;
		}
	}
	m_player[m_iTurn % 2].PromotionPiece(hWnd, m_iSelectedPieceNum, piece_type);
	return;
}

void GameManager::DropPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);

	//�ش� ��ġ�� ���õ� �ǽ��� �̵��Ҽ� �ִ��� Ȯ��
	int iCheckDrop = CheckDropPossible(ptMouse, m_iSelectedPieceNum,SELF);
	if (iCheckDrop != DROP_FALSE)
	{
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2);

		//���θ�� ����
		if (m_player[m_iTurn % 2].GetSelectedPieceType(m_iSelectedPieceNum) == PIECE_TYPE_PAWN)
		{
			RECT rectPawn = m_player[m_iTurn % 2].GetNthPieceRect(m_iSelectedPieceNum);
			if (((m_iTurn % 2) == WHITE && rectPawn.top == START_Y)
				|| ((m_iTurn % 2) == BLACK && rectPawn.top == START_Y + IMG_SIZE*IMG_RATE*7))
			{
				AlarmPromotion(hWnd, PIECE_TYPE_QUEEN);
			}
		}

		//üũ,üũ����Ʈ Ȯ��
		int iCheckResult = CheckGameEnd();
		switch (iCheckResult)
		{
		case GAME_END_NONE:
			break;
		case GAME_END_CHECK:
			MessageBox(hWnd, TEXT("Check!!!"), TEXT("Alaram"), MB_OK);
			break;
		case GAME_END_CHECKMATE:
			MessageBox(hWnd, TEXT("CheckMate!!!"), TEXT("Alaram"), MB_OK);
			int iMsgCheck = MessageBox(hWnd, TEXT("Again??"), TEXT("Alaram"), MB_OKCANCEL);
			m_player[WHITE].Release();
			m_player[BLACK].Release();
			if (iMsgCheck == 1)
			{
				m_player[WHITE].InitPlayer(hWnd, WHITE);
				m_player[BLACK].InitPlayer(hWnd, BLACK);
				m_iTurn = 0;
			}
			else
				SendMessage(hWnd, WM_DESTROY, 0, 0);
			break;
		}
		if(iCheckResult != GAME_END_CHECKMATE)
			m_iTurn++;
	}
	else
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2, iCheckDrop);
	InvalidateRect(hWnd, NULL, true);
}

bool GameManager::CheckPoint(RECT* rect, POINT point)
{
	if (PtInRect(rect, point))
		return true;
	else
		return false;
}

bool GameManager::CheckPawnMove(int move_dir,int mode, int player)
{
	bool bCheckPawn = true;
	if ((m_iTurn+ player) % 2 == WHITE)
	{
		if (move_dir == MOVE_DIR_TOP)
			bCheckPawn = true;
		else if(move_dir == MOVE_DIR_TOP_LEFT || move_dir == MOVE_DIR_TOP_RIGHT)
			bCheckPawn = false;
	}
	else if ((m_iTurn + player) % 2 == BLACK)
	{
		if (move_dir == MOVE_DIR_DOWN)
			bCheckPawn = true;
		else if (move_dir == MOVE_DIR_DOWN_LEFT || move_dir == MOVE_DIR_DOWN_RIGHT)
			bCheckPawn = false;
	}
	if (mode == PAWN_DROP_NONE)
		return bCheckPawn;
	else if(mode == PAWN_DROP_CATCH)
		return !bCheckPawn;
}

int GameManager::CheckAllPiece(RECT* pRect, int piece_num, int player, int search_mode)
{
	int iPieceCount = m_player[(m_iTurn + player + search_mode) % 2].GetPieceVecSize();
	for (int i = 0; i < iPieceCount; i++)
	{
		if (search_mode == SELF && i == piece_num)
			continue;
		RECT tmpRect = m_player[(m_iTurn + player + search_mode) % 2].GetNthPieceRect(i);
		POINT searchPoint = { tmpRect.left, tmpRect.top };
		if (CheckPoint(pRect, searchPoint))
			return i;
	}
	return -1;
}

//�Ű����� : �̵��� POINT, �̵��� �ǽ� �ѹ�, �̵��� �÷��̾�(���� : 0, ���:1)
int GameManager::CheckDropPossible(POINT point, int piece_index, int player, int mode)
{
	int iDropState = DROP_FALSE;
	if (m_player[(m_iTurn + player) % 2].GetPieceLiveState(piece_index) != true)
		return iDropState;
	std::vector<RECT>* possibleAllRect = m_player[(m_iTurn + player) % 2].GetAllMove(piece_index);
	std::vector<RECT> possibleRectVec;
	int iSelectedDir;
	for (int i = 0; i < DIR_COUNT; i++)
	{
		int iSize = possibleAllRect[i].size();
		bool bCheckDir = false;
		for (int j = 0; j < iSize; j++)
		{
			if (CheckPoint(&possibleAllRect[i][j], point))
			{
				bCheckDir = true;
				possibleRectVec = possibleAllRect[i];
				iSelectedDir = i;
				break;
			}
		}
		if (bCheckDir)
			break;
	}
	if (possibleRectVec.empty())
		iDropState = DROP_FALSE;
	else
	{
		int iCheckRectSize = possibleRectVec.size();
		int iPieceNum;
		for (int i = 0; i < iCheckRectSize; i++)
		{
			//���� �� ��ġ �浹 �˻� (�̵� ������ ��ġ - ���� �� ��ġ)
			iPieceNum = CheckAllPiece(&possibleRectVec[i], piece_index, player,SELF);
			if (iPieceNum != -1)
			{
				iDropState = DROP_FALSE;
				break;
			}
			//��� �� ��ġ �浹 �˻� (����Ʈ - ��� �� ��ġ) : ���
			iPieceNum = CheckAllPiece(&possibleRectVec[i], piece_index, player, OTHER);
			if (iPieceNum != -1)
			{
				if (CheckPoint(&possibleRectVec[i], point))
				{
					if (m_player[(m_iTurn + player) % 2].GetSelectedPieceType(piece_index) == PIECE_TYPE_PAWN)
					{
						if (CheckPawnMove(iSelectedDir, PAWN_DROP_CATCH, player))
							iDropState = DROP_CATCH;
						else
							iDropState = DROP_FALSE;
					}
					else
						iDropState = DROP_CATCH;
				}
				else
					iDropState = DROP_FALSE;
				if (mode == PLAY_DROP && iDropState == DROP_CATCH)
					CatchPiece(iPieceNum);
				break;
			}
			//�� ���� �δ� �� üũ(�̵�)
			if (CheckPoint(&possibleRectVec[i], point))
			{
				if (m_player[(m_iTurn + player) % 2].GetSelectedPieceType(piece_index) == PIECE_TYPE_PAWN)
				{
					if (CheckPawnMove(iSelectedDir, PAWN_DROP_NONE, player))
						iDropState = DROP_NO_CATCH;
					else
					{
						////Check EnPassant
						//if ()
						//{

						//}
						iDropState = DROP_FALSE;
					}
				}
				else
					iDropState = DROP_NO_CATCH;
				break;
			}
		}
	}
	return iDropState;
}

void GameManager::CatchPiece(int index)
{
	m_player[(m_iTurn + 1) % 2].CapturedPiece(index);
}