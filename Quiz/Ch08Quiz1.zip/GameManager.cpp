#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_character.InitCharacter(hWnd);
	m_bMoveTimer = false;
	m_bJumpTimer = false;
	m_ePdir = DIRECTION_START;
	m_iJumpLoopCount = 1;
	m_ePmoveState = MOVE_STATE_MOVE;
}

void GameManager::Draw(HWND hWnd, HDC hdc)
{
	m_character.DrawCharacter(hdc);
}

void GameManager::Move2(HWND hWnd, WPARAM move)
{
	if (m_bJumpTimer == false && m_bMoveTimer == false)
	{
		m_ePmoveState = MOVE_STATE_MOVE;
		switch (move)
		{
		case VK_DOWN:
			m_ePdir = DIRECTION_DOWN;
			break;
		case VK_UP:
			m_ePdir = DIRECTION_UP;
			break;
		case VK_LEFT:
			m_ePdir = DIRECTION_LEFT;
			break;
		case VK_RIGHT:
			m_ePdir = DIRECTION_RIGHT;
			break;
		}
		m_character.MoveCharacter2((int)m_ePdir, (int)m_ePmoveState);
		//m_bMoveTimer = true;
		//InvalidateRect(hWnd, NULL, true);
	}
}

void GameManager::Jump2(HWND hWnd)
{
	if (m_bJumpTimer == false)
	{
		if (GetKeyState(VK_LEFT) & 0x8000 || GetKeyState(VK_RIGHT) & 0x8000)
			m_ePmoveState = MOVE_STATE_MOVING_JUMP;
		else
			m_ePmoveState = MOVE_STATE_JUMP;
	}
	if (!m_character.JumpCharacter((int)m_ePmoveState, m_iJumpLoopCount++))
	{
		m_bJumpTimer = true;
		SetTimer(hWnd, 2, JUMP_TIME, NULL);
		InvalidateRect(hWnd, NULL, true);
	}
	else
	{
		m_ePmoveState = MOVE_STATE_MOVE;
		m_iJumpLoopCount = 1;
		m_bJumpTimer = false;
		KillTimer(hWnd, 2);
	}
}

void GameManager::MoveEnd(HWND hWnd, WPARAM wParam)
{
	if (wParam != 1)
	{
		m_character.StopCharacter();
		//InvalidateRect(hWnd, NULL, true);
	}
	m_bMoveTimer = false;
	//KillTimer(hWnd, 1);
}