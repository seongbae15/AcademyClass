#pragma once
#include<windows.h>
#include "resource.h"

#define IMG_WIDTH 145
#define IMG_HEIGHT 235
#define START_X 20
#define START_Y 20
#define FIRST_IMG_NUMBER 101

enum IMG_LIST
{
	IMG_LIST1 = 101,
	IMG_LIST2,
	IMG_LIST3,
	IMG_LIST4,
	IMG_LIST5,
	IMG_LIST6,
	IMG_LIST7,
	IMG_LIST8,
	IMG_LIST9,
	IMG_LIST10,
};

typedef struct ImageInfo
{
	int iX;
	int iY;
	bool bImgState;
	LPCTSTR lpStrName;
	int iImgNumber;
};

class Card
{
private:
	ImageInfo m_stInfo;
public:
	Card() {};
	~Card() {};
	void SetCard(int number);
	void ShowCard(HDC hdc, HINSTANCE g_hInst, int number);
	void FlipCard();
	inline int GetPosX()
	{
		return m_stInfo.iX;
	}
	inline int GetPosY()
	{
		return m_stInfo.iY;
	}
	inline LPCTSTR GetCardName()
	{
		return m_stInfo.lpStrName;
	}

};

