#pragma once
template <typename tp>
class Singletone
{
private:
	static tp* m_pThis;
protected:
	Singletone() {};
	virtual  ~Singletone() {};
public:
	static tp* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new tp;
		return m_pThis;
	}
	static void ReleaseInstance()
	{
		if (m_pThis)
		{
			delete m_pThis;
			m_pThis = NULL;
		}

	}
};

template <typename tp> tp* Singletone<tp>::m_pThis = 0;