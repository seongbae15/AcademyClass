#pragma once
#include "Card.h"

#include "Singletone.h"
#include <vector>

#define MAX 10

using namespace std;

class CardManager : public Singletone<CardManager>
{
private:
	vector<Card*> m_vecCardList;
public:
	CardManager();
	void RegisterCard();
	void DrawCard(HDC hdc, HINSTANCE g_hInst);
	int CheckCardFlip(int mouseX, int mouseY);
	LPCTSTR GetNthCardName(int number);
};

