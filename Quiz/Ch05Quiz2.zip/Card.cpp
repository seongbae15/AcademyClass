#include "Card.h"

void Card::SetCard(int number)
{
	m_stInfo.bImgState = false;
	if (number < 5)
	{
		m_stInfo.iX = START_X + (IMG_WIDTH + 20) * number;
		m_stInfo.iY = START_Y;
	}
	else
	{
		m_stInfo.iX = START_X + (IMG_WIDTH + 20) * (number - 5);
		m_stInfo.iY = START_Y + (IMG_HEIGHT + 20);
	}
	m_stInfo.iImgNumber = FIRST_IMG_NUMBER + number;
	switch ((IMG_LIST)m_stInfo.iImgNumber)
	{
	case IMG_LIST1:
		m_stInfo.lpStrName = TEXT("������");
		break;
	case IMG_LIST2:
		m_stInfo.lpStrName = TEXT("ȣ����");
		break;
	case IMG_LIST3:
		m_stInfo.lpStrName = TEXT("����");
		break;
	case IMG_LIST4:
		m_stInfo.lpStrName = TEXT("�ڳ���");
		break;
	case IMG_LIST5:
		m_stInfo.lpStrName = TEXT("��");
		break;
	case IMG_LIST6:
		m_stInfo.lpStrName = TEXT("��");
		break;
	case IMG_LIST7:
		m_stInfo.lpStrName = TEXT("������");
		break;
	case IMG_LIST8:
		m_stInfo.lpStrName = TEXT("������");
		break;
	case IMG_LIST9:
		m_stInfo.lpStrName = TEXT("������");
		break;
	case IMG_LIST10:
		m_stInfo.lpStrName = TEXT("��");
		break;
	default:
		break;
	}
}

void Card::ShowCard(HDC hdc, HINSTANCE g_hInst, int number)
{
	HDC hMemdc;
	HBITMAP myBitmap, oldBitmap;
	hMemdc = CreateCompatibleDC(hdc);
	if(m_stInfo.bImgState == true)
		myBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(m_stInfo.iImgNumber));
	else
		myBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP11));
	oldBitmap = (HBITMAP)SelectObject(hMemdc, myBitmap);
	if (number < 5)
		BitBlt(hdc, m_stInfo.iX, m_stInfo.iY, IMG_WIDTH, IMG_HEIGHT, hMemdc, 0, 0, SRCCOPY);
	else
		BitBlt(hdc, m_stInfo.iX, m_stInfo.iY, IMG_WIDTH, IMG_HEIGHT, hMemdc, 0, 0, SRCCOPY);
	SelectObject(hMemdc, oldBitmap);
	DeleteObject(myBitmap);
}

void Card::FlipCard()
{
	if (m_stInfo.bImgState == false)
		m_stInfo.bImgState = true;
}
