#include "CardManager.h"

CardManager::CardManager()
{
	for (int i = 0; i < MAX; i++)
	{
		m_vecCardList.push_back(new Card);
	}
}

void CardManager::RegisterCard()
{
	for (int i = 0; i < MAX; i++)
	{
		m_vecCardList[i]->SetCard(i);
	}
}

void CardManager::DrawCard(HDC hdc, HINSTANCE g_hInst)
{
	for (int i = 0; i < MAX; i++)
	{
		m_vecCardList[i]->ShowCard(hdc, g_hInst,i);
	}
}

int CardManager::CheckCardFlip(int mouseX, int mouseY)
{
	for (int i = 0; i < MAX; i++)
	{
		if((mouseX >= m_vecCardList[i]->GetPosX() && mouseX <= (m_vecCardList[i]->GetPosX() + IMG_WIDTH))
			&& (mouseY >= m_vecCardList[i]->GetPosY() && mouseY <= (m_vecCardList[i]->GetPosY() + IMG_HEIGHT)))
		{
			m_vecCardList[i]->FlipCard();
			return i;
		}
	}
	return -1;
}

LPCTSTR CardManager::GetNthCardName(int number)
{
	return m_vecCardList[number]->GetCardName();
}