#include "Character.h"

void Character::InitCharacter(HWND hWnd)
{
	HDC hdc = GetDC(hWnd);
	m_bitmap.Init(hdc, TEXT("CharacterIMG.bmp"));
	ReleaseDC(hWnd, hdc);
	m_stInfo.iX = WIN_WIDTH / 2;
	m_stInfo.iY = WIN_HEIGHT / 2;
	m_stInfo.eDir = DIRECTION_DOWN;
	m_stInfo.iStep = 0;
	m_stInfo.eMove = MOVE_STATE_MOVE;
}

void Character::DrawCharacter(HDC hdc)
{
	SIZE tmpImgSize = m_bitmap.GetImgSize();
	m_bitmap.Draw(hdc, m_stInfo.iX - tmpImgSize.cx/2, m_stInfo.iY- tmpImgSize.cy/2, m_stInfo.iStep, int(m_stInfo.eDir));
}

void Character::MoveCharacter(int move_dir, int move_state)
{
	m_stInfo.eMove = (MOVE_STATE)move_state;

	if (move_dir >= (int)DIRECTION_START && move_dir <= (int)DIRECTION_END)
	{
		m_stInfo.eDir = (DIRECTION)move_dir;
		SIZE tmpImgSize = m_bitmap.GetImgSize();
		switch (m_stInfo.eDir)
		{
		case DIRECTION_DOWN:
			if (m_stInfo.iY + tmpImgSize.cy < MOVING_MAX_Y)
				m_stInfo.iY += MOVE_STEP;
			break;
		case DIRECTION_UP:
			if(m_stInfo.iY - tmpImgSize.cy / 2 > MOVING_MIN_Y)
				m_stInfo.iY -= MOVE_STEP;
			break;
		case DIRECTION_LEFT:
			if (m_stInfo.iX - tmpImgSize.cx / 2 > MOVING_MIN_X)
				m_stInfo.iX -= MOVE_STEP;
			break;
		case DIRECTION_RIGHT:
			if (m_stInfo.iX + tmpImgSize.cx < MOVING_MAX_X)
				m_stInfo.iX += MOVE_STEP;
			break;
		default:
			break;
		}
	}

	if (m_stInfo.iStep < MAX_STEP)
		m_stInfo.iStep++;
	else
		m_stInfo.iStep = 0;
}

bool Character::JumpCharacter(int move_state,int loop_count)
{
	m_stInfo.eMove = (MOVE_STATE)move_state;
	if (m_stInfo.eMove == MOVE_STATE_MOVING_JUMP)
	{
		if(loop_count == 1)
			m_stInfo.iJumpInitX = m_stInfo.iX;
		switch (m_stInfo.eDir)
		{
		case DIRECTION_LEFT:
			if (m_stInfo.iX - m_bitmap.GetImgSize().cx/2 > MOVING_MIN_X)
				m_stInfo.iX -= VEL_UP * 0.1f;
			break;
		case DIRECTION_RIGHT:
			if (m_stInfo.iX + m_bitmap.GetImgSize().cx < MOVING_MAX_X)
				m_stInfo.iX += VEL_UP * 0.1f;
			break;
		}
	}
	if (loop_count == 1)
		m_stInfo.iJumpInitY = m_stInfo.iY;
	else if(loop_count == MAX_JUMP_COUNT)
	{
		//���� ����
		m_stInfo.eMove = MOVE_STATE_MOVE;
		return true;
	}
	m_stInfo.iY = m_stInfo.iJumpInitY - (VEL_UP * (loop_count * 0.1f))
		+ (0.5f * ACC_G * (loop_count * 0.1f) * (loop_count * 0.1f));
	if (m_stInfo.iY == (m_stInfo.iJumpInitY - JUMP_DISTANCE) && m_stInfo.iStep % 2 == 0
		|| m_stInfo.iY == m_stInfo.iJumpInitY && m_stInfo.iStep % 2 == 1)
	{
		if (m_stInfo.iStep == MAX_STEP)
			m_stInfo.iStep = 0;
		else
			m_stInfo.iStep++;
	}
	return false;
}

void Character::StopCharacter()
{
	if(m_stInfo.iStep == MAX_STEP)
		m_stInfo.iStep = 0;
	else if(m_stInfo.iStep == 1)
		m_stInfo.iStep++;
}