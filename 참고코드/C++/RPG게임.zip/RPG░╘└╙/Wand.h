#pragma once
#include"Weapon.h"
class Wand : public Weapon
{
public:
	Wand();
	int Draw();
	void Set();
	~Wand();
};

