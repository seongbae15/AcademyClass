#pragma once
#include"Weapon.h"
class Sword : public Weapon
{
public:
	Sword();
	int Draw();
	void Set();
	~Sword();
};

