#include "Hammer.h"



Hammer::Hammer()
{
	Set();
}
void Hammer::Set()
{
	ofstream Save;
	Save.open("HammerList.txt");
	if (Save.is_open())
	{
		Save << "5" << endl;
		Save << "Hammer ��ö��ġ 30 70" << endl;
		Save << "Hammer �丣�Ǹ�ġ 50 110" << endl;
		Save << "Hammer �̽������� 75 170" << endl;
		Save << "Hammer ���Ŭ���� 150 320" << endl;
		Save << "Hammer �������� 210 450" << endl;
		Save.close();
	}

	ifstream Load;
	Load.open("HammerList.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		WeaPons = new WP[m_iCount];
		for (int i = 0; m_iCount; i++)
		{
			Load >> WeaPons[i].iType;
			Load >> WeaPons[i].strName;
			Load >> WeaPons[i].iWeaponAttack;
			Load >> WeaPons[i].iPrice;
		}
	}
}
int Hammer::Draw()
{
	int h = HEIGHT * 0.1;
	for (int i = 0; i < m_iCount; i++)
	{
		YELLOW
			DrawManager.gotoxy(WIDTH / 2, h);
			cout << "���� : " << WeaPons[i].iPrice << " ����Ÿ�� : �ظ�";
			DrawManager.gotoxy(WIDTH / 2, ++h);
		cout << "�����̸� : " << WeaPons[i].strName << " ���ݷ� : " << WeaPons[i].iWeaponAttack;
		++h;
		ORIGINAL
	}
	return DrawManager.MenuSelectCursor(m_iCount, 4, 5, HEIGHT*0.1);
}

Hammer::~Hammer()
{
	delete[] WeaPons;
}
