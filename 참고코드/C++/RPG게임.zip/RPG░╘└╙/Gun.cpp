#include "Gun.h"



Gun::Gun()
{
	Set();
}
void Gun::Set()
{
	ofstream Save;
	Save.open("GunList.txt");
	if (Save.is_open())
	{
		Save << "4" << endl;
		Save << "Gun ������ 15 30" << endl;
		Save << "Gun ������ 25 50" << endl;
		Save << "Gun ������ 40 80" << endl;
		Save << "Gun ���¶��̴� 120 240" << endl;
		
		Save.close();
	}

	ifstream Load;
	Load.open("GunList.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		WeaPons = new WP[m_iCount];
		for (int i = 0; m_iCount; i++)
		{
			Load >> WeaPons[i].iType;
			Load >> WeaPons[i].strName;
			Load >> WeaPons[i].iWeaponAttack;
			Load >> WeaPons[i].iPrice;
		}
	}
}
int Gun::Draw()
{
	int h = HEIGHT * 0.1;
	for (int i = 0; i < m_iCount; i++)
	{
		YELLOW
			DrawManager.gotoxy(WIDTH / 2, h);
			cout << "���� : " << WeaPons[i].iPrice << " ����Ÿ�� : ��" << endl;
			DrawManager.gotoxy(WIDTH / 2, ++h);
		cout << "�����̸� : " << WeaPons[i].strName << " ���ݷ� : " << WeaPons[i].iWeaponAttack << endl;
		++h;
		ORIGINAL
	}
	return DrawManager.MenuSelectCursor(m_iCount, 4, 5, HEIGHT*0.1);
}

Gun::~Gun()
{
	delete[] WeaPons;
}
