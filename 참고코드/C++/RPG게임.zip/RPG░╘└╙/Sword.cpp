#include "Sword.h"



Sword::Sword()
{
	Set();
}
void Sword::Set()
{
	ofstream Save;
	Save.open("SwordList.txt");
	if (Save.is_open())
	{
		Save << "5" << endl;
		Save << "Sword �ǹ��ҵ� 13 30" << endl;
		Save << "Sword ��������� 33 70" << endl;
		Save << "Sword �ֵ��ν� 45 100" << endl;
		Save << "Sword ����� 80 180" << endl;
		Save << "Sword �����ҵ� 150 350" << endl;
		Save.close();
	}

	ifstream Load;
	Load.open("SwordList.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		WeaPons = new WP[m_iCount];
		for (int i = 0; m_iCount; i++)
		{
			Load >> WeaPons[i].iType;
			Load >> WeaPons[i].strName;
			Load >> WeaPons[i].iWeaponAttack;
			Load >> WeaPons[i].iPrice;
		}
	}
}
int Sword::Draw()
{
	int h = HEIGHT * 0.1;
	for (int i = 0; i < m_iCount; i++)
	{
		YELLOW
			DrawManager.gotoxy(WIDTH / 2, h);
			cout << "���� : " << WeaPons[i].iPrice << " ����Ÿ�� : �ҵ�" ;
			DrawManager.gotoxy(WIDTH / 2, ++h);
		cout << "�����̸� : " << WeaPons[i].strName << " ���ݷ� : " << WeaPons[i].iWeaponAttack;
		++h;
		ORIGINAL
	}
	return DrawManager.MenuSelectCursor(m_iCount, 4, 5, HEIGHT*0.1);
}


Sword::~Sword()
{
	delete[] WeaPons;
}
