#include "Bow.h"



Bow::Bow()
{
	Set();
}
void Bow::Set()
{
	ofstream Save;
	Save.open("BowList.txt");
	if (Save.is_open())
	{
		Save << "5" << endl;
		Save << "Bow ����Ʈ���� 10 20" << endl;
		Save << "Bow ũ�ν����� 15 30" << endl;
		Save << "Bow ��ź�Ƶ�Ʈ 30 60" << endl;
		Save << "Bow ��ǳ�ǿ��� 50 100" << endl;
		Save << "Bow �������巹�� 150 300" << endl;
		Save.close();
	}

	ifstream Load;
	Load.open("BowList.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		WeaPons = new WP[m_iCount];
		for (int i = 0; m_iCount; i++)
		{
			Load >> WeaPons[i].iType;
			Load >> WeaPons[i].strName;
			Load >> WeaPons[i].iWeaponAttack;
			Load >> WeaPons[i].iPrice;
		}
	}
}
int Bow::Draw()
{
	int h = HEIGHT * 0.1;
	for (int i = 0; i < m_iCount; i++)
	{
		YELLOW
			DrawManager.gotoxy(WIDTH / 2, h);
		cout << "���� : " << WeaPons[i].iPrice << " ����Ÿ�� : ����";
		DrawManager.gotoxy(WIDTH / 2, ++h);
		cout << "�����̸� : " << WeaPons[i].strName << " ���ݷ� : " << WeaPons[i].iWeaponAttack;
		++h;
		ORIGINAL
	}

	return DrawManager.MenuSelectCursor(m_iCount, 4, 5, HEIGHT*0.1);
}


Bow::~Bow()
{
	delete[] WeaPons;
}
