#pragma once
#include "Weapon.h"

class Gun : public Weapon
{
public:
	Gun();
	int Draw();
	void Set();
	~Gun();
};

