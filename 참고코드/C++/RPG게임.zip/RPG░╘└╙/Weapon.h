#pragma once
#include"Mecro.h"
#include"MapDraw.h"
struct WP
{
	string strName;
	int iPrice;
	int iType;
	int iWeaponAttack;
};
class Weapon
{
protected:
	int m_iCount;
	WP *WeaPons;
	MapDraw DrawManager;
public:
	Weapon();
	virtual int Draw() = 0;
	virtual void Set() = 0;
	~Weapon();
};



















