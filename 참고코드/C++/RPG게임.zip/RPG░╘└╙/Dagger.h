#pragma once
#include "Weapon.h"
class Dagger : public Weapon
{
public:
	Dagger();
	int Draw();
	void Set();
	~Dagger();
};

