#include "Character.h"



Character::Character()
{
	h = HEIGHT * 0.1;
	w = WIDTH / 2;
	m_iGameover = 0;
	m_iSelectNum = 0;
	SetDefault();
}
void Character::SetDefault()
{
	ofstream Save;
	Save.open("Default.txt");
	if (Save.is_open())
	{
		Save << "500 50 10 0 1 1 10" << endl;
		Save << "6" << endl;
		Save << "������ 3 20 5 5 1 0 10" << endl;
		Save << "�Ķ������� 20 100 20 50 1 0 20" << endl;
		Save << "���������� 50 250 50 250 1 0 30" << endl;
		Save << "��Ȳ���� 120 500 500 700 1 0 40" << endl;
		Save << "�Թ��� 200 800 200 1500 1 0 50" << endl;
		Save << "������� 300 3000 300 3000 1 0 60" << endl;
		Save.close();
	}

	ifstream Load;
	Load.open("Default.txt");

	Load >> m_PLAYER.iAttack;
	Load >> m_PLAYER.iMaxHealth;
	m_PLAYER.iCurHealth = m_PLAYER.iMaxHealth;
	m_PLAYER.iEXP = 0;
	Load >> m_PLAYER.iMaxEXP;
	Load >> m_PLAYER.iGetEXP;
	Load >> m_PLAYER.iLevel;
	Load >> m_PLAYER.iType;
	Load >> m_PLAYER.iGold;

	Load >> m_iStage;

	m_ENEMY = new CHARAC[m_iStage];
	for (int i = 0; i < m_iStage; i++)
	{
		
		Load >> m_ENEMY[i].strName;
		Load >> m_ENEMY[i].iAttack;
		Load >> m_ENEMY[i].iMaxHealth;
		m_ENEMY[i].iCurHealth = m_ENEMY[i].iMaxHealth;
		m_ENEMY[i].iEXP = 0;
		Load >> m_ENEMY[i].iMaxEXP;
		Load >> m_ENEMY[i].iGetEXP;
		Load >> m_ENEMY[i].iLevel;
		Load >> m_ENEMY[i].iType;
		Load >> m_ENEMY[i].iGold;
	}

	Load.close();
}
void Character::ShowPlayerDetail()
{
	h = HEIGHT * 0.1;
	w = WIDTH / 2;
	ShowDetail(&m_PLAYER);
	DrawManager.gotoxy(0, 33);
}
void Character::ShowMonsterDetail()
{
	h = HEIGHT * 0.1;
	w = WIDTH / 2;
	for (int i = 0; i < m_iStage; i++)
	{
		ShowDetail(&m_ENEMY[i]);
		h++;
	}
	
	DrawManager.gotoxy(0, 33);
}
void Character::ShowDetail(CHARAC* C)
{
	DrawManager.gotoxy(w, h);
	RED
	cout <<"====== "<< C->strName << " ( " << C->iLevel << " Lv ) ======";
	ORIGINAL
	DrawManager.gotoxy(w, ++h);
	cout <<"���ݷ� = "<< C->iAttack << "    ������ = " << C->iCurHealth << " / " << C->iMaxHealth;
	DrawManager.gotoxy(w, ++h);
	cout<<"����ġ = " << C->iEXP << " / " << C->iMaxEXP << "    GetEXP : " << C->iGetEXP ;
	DrawManager.gotoxy(w, ++h);
	cout<<"��� = " << C->iGold << " G";
}
void Character::ShowFightPage(int i)
{
	
	h = HEIGHT * 0.1;
	w = WIDTH /2;
	ShowDetail(&m_PLAYER);
	++h;
	DrawManager.TextDraw("���� : 0 , ���� : 1, �� : 2",w,++h);
	DrawManager.TextDraw("===========================VS===========================", 2, HEIGHT/2);
	h = HEIGHT * 0.75;
	ShowDetail(&m_ENEMY[i]);
}
int Character::EnemySelect()
{
	int k = HEIGHT * 0.3;

	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	DrawManager.DrawMidText("�ƢƢ� DONGEON �ƢƢ�", WIDTH, HEIGHT *0.2);
	for (int i = 0; i < m_iStage; i++)
	{
		DrawManager.gotoxy(WIDTH/2 +5, k);
		cout << i + 1 << "�� ���� : [ " << m_ENEMY[i].strName << " ]";
		k += 3;
	}
	return( DrawManager.MenuSelectCursor(m_iStage, 3,7, HEIGHT*0.3) -1 );
}
void Character::Fight(int index) // index-1 is monster number
{
	while (!m_iGameover)
	{	system("cls");
		DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		ShowFightPage(index);
		while (1)
		{
			DrawManager.gotoxy(WIDTH , HEIGHT *0.3);
			cin >> m_iPlayerChoice;
			if (m_iPlayerChoice >= 0 && m_iPlayerChoice <= 2)
				break;
		}

		h = HEIGHT * 0.4;
		w = WIDTH;
		m_iEnemyChoice = rand() % 3; // 0-2 
		ShowChoice(m_iPlayerChoice);
		ShowChoice(m_iEnemyChoice);
		if (m_iPlayerChoice == m_iEnemyChoice)
		{
			RED
			DrawManager.TextDraw("DRAW", WIDTH-2, HEIGHT*0.45);
			DrawManager.TextDraw("DRAW", WIDTH - 2, HEIGHT*0.57);
			ORIGINAL
		}
		else if (m_iPlayerChoice > m_iEnemyChoice)
		{
			if (m_iPlayerChoice == �� && m_iEnemyChoice == ����)
			{
				RED
					DrawManager.TextDraw("LOSE", WIDTH - 2, HEIGHT*0.45);
					DrawManager.TextDraw("WIN", WIDTH - 2, HEIGHT*0.57);
				ORIGINAL
				Attack(&m_ENEMY[index], &m_PLAYER);
			}
			else
			{
				RED
				DrawManager.TextDraw("WIN", WIDTH - 2, HEIGHT*0.45);
				DrawManager.TextDraw("LOSE", WIDTH - 2, HEIGHT*0.57);
				ORIGINAL
				Attack(&m_PLAYER, &m_ENEMY[index]);
			}
		}
		else
		{
			if (m_iPlayerChoice == ���� && m_iEnemyChoice == ��)
			{
				RED
				DrawManager.TextDraw("WIN", WIDTH - 2, HEIGHT*0.45);
				DrawManager.TextDraw("LOSE", WIDTH - 2, HEIGHT*0.57);
				ORIGINAL
					Attack(&m_PLAYER, &m_ENEMY[index]);
			}
			else 
			{
				RED
				DrawManager.TextDraw("LOSE", WIDTH - 2, HEIGHT*0.45);
				DrawManager.TextDraw("WIN", WIDTH - 2, HEIGHT*0.57);
				ORIGINAL
				Attack(&m_ENEMY[index], &m_PLAYER);
			}
		}
		DrawManager.gotoxy(0, 33);
		system("pause");
		if (m_PLAYER.iCurHealth <= 0)
		{
			system("cls");
			DrawManager.TextDraw(m_ENEMY[index].strName, WIDTH / 2, HEIGHT*0.4);
			DrawManager.TextDraw("!!!!WIN!!!!", WIDTH / 2, HEIGHT*0.5);
			ExpUp(&m_ENEMY[index],&m_PLAYER);
			return;
		}
		else if (m_ENEMY[index].iCurHealth <= 0)
		{
			system("cls");
			DrawManager.TextDraw(m_PLAYER.strName, WIDTH / 2, HEIGHT*0.4);
			DrawManager.TextDraw("!!!!WIN!!!!", WIDTH / 2, HEIGHT*0.5);
			ExpUp(&m_PLAYER,&m_ENEMY[index]);
			return;
		}
	}
}
void Character::ExpUp(CHARAC* P1, CHARAC* P2)
{
	int Num; 
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	DrawManager.DrawPoint(P1->strName, WIDTH / 2, HEIGHT*0.4);
	DrawManager.DrawMidText("�¸�!!", WIDTH / 2, HEIGHT*0.5);
	if (P2->iType == PLAYER && P2->iGetEXP == 0)
	{
		cout << "GAME OVER!!" << endl;
		m_iGameover = 1;
		system("pause");
		return;
	}
	P1->iEXP += P2->iGetEXP;
	P1->iGold += P2->iGold;
	if (P2->iType == PLAYER)
	{
		P2->iEXP = 0;
		P2->iGetEXP = 0;
	}
	if (P1->iEXP >= P1->iMaxEXP)
		LevelUp(P1);

	if (P1->iType == PLAYER)
	{
		P1->iGetEXP = P1->iEXP;
		P1->iCurHealth = P1->iMaxHealth;
		
	}
	system("pause");
}
void Character::LevelUp(CHARAC* P1)
{
	int Num;
	cout << P1->strName << "������!" << endl;
	Num = rand() % (UPATTACK + 1); 
	P1->iAttack += Num;
	cout << "���ݷ� < " << Num << " > ��ŭ ����!" << endl;
	Num = rand() % (UPHEALTH + 1);
	P1->iMaxHealth += Num;
	cout << "������ < " << Num << " > ��ŭ ����!" << endl;
	P1->iEXP = 0;
	P1->iMaxEXP += P1->iMaxEXP * 0.2;
	P1->iLevel++;
	P1->iCurHealth = P1->iMaxHealth;
}
void Character::Attack(CHARAC* P1, CHARAC* P2)
{
	P2->iCurHealth -= P1->iAttack;
	if (P2->iCurHealth < 0)
		P2->iCurHealth = 0;
}
void Character::ShowChoice(int Num)
{

	switch (Num)
	{
	case ����:
		DrawManager.TextDraw("�� ���� ��", w-4, h);
		break;
	case ����:
		DrawManager.TextDraw("�� ���� ��", w-4, h);
		break;
	case ��:
		DrawManager.TextDraw("�� �� ��", w-4, h);
		break;
	default:
		break;
	}
	h += 6;
	
}
void Character::FileList()
{

	char buf[256];
	for (int i = 1; i <= 10; i++)
	{
		sprintf(buf, "SaveFile%d.txt", i); 
		ifstream Save;
		Save.open(buf);
		DrawManager.gotoxy(WIDTH / 2,i+10);
		GREEN
			cout << i << " �� ���� : ( ���� ���� : ";
		if (Save.is_open() == NULL)
			cout << " X )" << endl;
		else
		{
			cout << " O )" << endl;
			Save.close();
		}
		ORIGINAL
	}
	GREEN
	m_iSelectNum=DrawManager.MenuSelectCursor(10, 1, 5, 11);
	ORIGINAL
	system("pause");
}
void Character::Save()
{
	char buf[256];

	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	FileList();
	ofstream Save;
	sprintf(buf, "SaveFile%d.txt", m_iSelectNum);
	Save.open(buf);
	if (Save.is_open())
	{
		Save << m_PLAYER.strName<< " ";
		Save << m_PLAYER.iAttack<< " ";
		Save << m_PLAYER.iCurHealth << " ";
		Save << m_PLAYER.iMaxHealth << " ";
		Save << m_PLAYER.iEXP << " ";
		Save << m_PLAYER.iGetEXP << " ";
		Save << m_PLAYER.iMaxEXP << " ";
		Save << m_PLAYER.iLevel << " ";
		Save << m_PLAYER.iType << " ";
		Save << m_PLAYER.iGold <<endl;
		Save << m_iStage<<endl;
		for (int i = 0; i < m_iStage; i++)
		{
			Save << m_ENEMY[i].strName << " ";
			Save << m_ENEMY[i].iAttack << " ";
			Save << m_ENEMY[i].iCurHealth << " ";
			Save << m_ENEMY[i].iMaxHealth << " ";
			Save << m_ENEMY[i].iEXP << " ";
			Save << m_ENEMY[i].iGetEXP << " ";
			Save << m_ENEMY[i].iMaxEXP << " ";
			Save << m_ENEMY[i].iLevel << " ";
			Save << m_ENEMY[i].iType << " ";
			Save << m_ENEMY[i].iGold << endl;
		}
		Save.close();
	}


}
void Character::Load()
{
	ifstream Load;
	char buf[256];
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	FileList();
	sprintf(buf, "SaveFile%d.txt", m_iSelectNum);
	Load.open(buf);
	if (Load.is_open() == NULL)
	{
		cout << "�ش� ���� ������ �����ϴ�." << endl;
		system("pause");
		return;
	}
	Load>> m_PLAYER.strName ;
	Load >> m_PLAYER.iAttack ;
	Load >> m_PLAYER.iCurHealth;
	Load >> m_PLAYER.iMaxHealth;
	Load >> m_PLAYER.iEXP ;
	Load >> m_PLAYER.iGetEXP;
	Load >> m_PLAYER.iMaxEXP;
	Load >> m_PLAYER.iLevel ;
	Load >> m_PLAYER.iType ;
	Load >> m_PLAYER.iGold ;
	Load>>  m_iStage ;
	for (int i = 0; i < m_iStage; i++)
	{
		Load >> m_ENEMY[i].strName ;
		Load >> m_ENEMY[i].iAttack ;
		Load >> m_ENEMY[i].iCurHealth;
		Load >> m_ENEMY[i].iMaxHealth;
		Load >> m_ENEMY[i].iEXP ;
		Load >> m_ENEMY[i].iGetEXP ;
		Load >> m_ENEMY[i].iMaxEXP ;
		Load >> m_ENEMY[i].iLevel ;
		Load>> m_ENEMY[i].iType ;
		Load >> m_ENEMY[i].iGold;
	}
	Load.close();

	
}
Character::~Character()
{
	delete[] m_ENEMY;
	delete &m_PLAYER;
}

