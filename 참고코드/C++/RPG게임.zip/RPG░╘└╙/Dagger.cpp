#include "Dagger.h"



Dagger::Dagger()
{
	Set();
}

void Dagger::Set()
{
	ofstream Save;
	Save.open("DaggerList.txt");
	if (Save.is_open())
	{
		Save << "6" << endl;
		Save << "Dagger �̴ϴ�� 5 20" << endl;
		Save << "Dagger �ǹ���� 10 40" << endl;
		Save << "Dagger ����� 30 120" << endl;
		Save << "Dagger �÷�Ƽ�Ѵ�� 50 200" << endl;
		Save << "Dagger ���̾ƴ�� 80 320" << endl;
		Save << "Dagger �������� 150 350" << endl;
		Save.close();
	}

	ifstream Load;
	Load.open("DaggerList.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		WeaPons = new WP[m_iCount];
		for (int i = 0; m_iCount; i++)
		{
			Load >> WeaPons[i].iType;
			Load >> WeaPons[i].strName;
			Load >> WeaPons[i].iWeaponAttack;
			Load >> WeaPons[i].iPrice;
		}
	}
}
int Dagger::Draw()
{
	int h = HEIGHT * 0.1;
	for (int i = 0; i < m_iCount; i++)
	{
		YELLOW
			DrawManager.gotoxy(WIDTH / 2, h);
			cout << "���� : " << WeaPons[i].iPrice << " ����Ÿ�� : ���";
			DrawManager.gotoxy(WIDTH / 2, ++h);
		cout << "�����̸� : " << WeaPons[i].strName << " ���ݷ� : " << WeaPons[i].iWeaponAttack ;
		++h;
		ORIGINAL
	}
	return DrawManager.MenuSelectCursor(m_iCount, 4, 5, HEIGHT*0.1);

}
Dagger::~Dagger()
{
	delete[] WeaPons;
}
