#pragma once
#include"Weapon.h"
class Bow : public Weapon
{
public:
	Bow();
	int Draw();
	void Set();
	~Bow();
};

