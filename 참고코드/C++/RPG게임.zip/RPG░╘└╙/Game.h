#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Character.h"
#include"Weapon.h"
#include"Dagger.h"
#include"Bow.h"
#include"Hammer.h"
#include"Gun.h"
#include"Sword.h"
#include"Wand.h"

class Game
{
private:
	MapDraw DrawManager;
	Character Character;
	Weapon* tmp;
public:
	Game();
	void MainPage(); 
	void MenuPage();
	void DongeonPage();
	void NewGame();
	void LoadGame();
	void PInfo();
	void MInfo();
	void WeaponePage();
	~Game();
};

