#pragma once
#include"Weapon.h"
class Hammer : public Weapon
{
public:
	Hammer();
	int Draw();
	void Set();
	~Hammer();
};

