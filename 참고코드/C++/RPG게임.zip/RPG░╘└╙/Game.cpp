#include "Game.h"



Game::Game()
{

}
 
void Game::MainPage() // WHEN START GAME
{
	int iSelect;
	bool bState = false;
	while (!bState)
	{
		DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		DrawManager.DrawMidText("�ڡ� TEXT RPG GAME �ڡ�", WIDTH, HEIGHT * 0.3);
		DrawManager.DrawMidText("1. New Game ", WIDTH, HEIGHT * 0.4);
		DrawManager.DrawMidText("2. Load Game", WIDTH, HEIGHT * 0.5);
		DrawManager.DrawMidText("3. Game Exit", WIDTH, HEIGHT * 0.6);
		iSelect = DrawManager.MenuSelectCursor(3, 3, 10, HEIGHT*0.4);
		switch (iSelect)
		{
		case MAIN_NEW:
			NewGame();
			break;
		case MAIN_LOAD:
			LoadGame();
			break;
		case MAIN_EXIT:
			bState = true;
			return;
		default:
			break;
		}
	}
}
void Game::MenuPage()
{
	int iSelect;
	bool bState = false;
	while (!bState)
	{
		system("cls");
		DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		DrawManager.DrawMidText("�ڡ� MENU �ڡ�", WIDTH, HEIGHT * 0.2);
		DrawManager.DrawMidText("DONGEON ", WIDTH, HEIGHT * 0.3);
		DrawManager.DrawMidText("PLAYER INFO", WIDTH, HEIGHT * 0.4);
		DrawManager.DrawMidText("MONSTER INFO", WIDTH, HEIGHT * 0.5);
		DrawManager.DrawMidText("WEAPON SHOP", WIDTH, HEIGHT * 0.6);
		DrawManager.DrawMidText("SAVE", WIDTH, HEIGHT * 0.7);
		DrawManager.DrawMidText("EXIT", WIDTH, HEIGHT * 0.8);
		iSelect = DrawManager.MenuSelectCursor(6, 3, 10, HEIGHT*0.3);

		switch (iSelect)
		{
		case MENU_DONGEON:
			DongeonPage();
			break;
		case MENU_PINFO:
			PInfo();
			break;
		case MENU_MINFO:
			MInfo();
			break;
		case MENU_WEAPONSHOP:
			WeaponePage();
			break;
		case MENU_SAVE:
			Character.Save();
			break;
		case MENU_EXIT:
			bState = true;
			return;
		default:
			break;
		}
	}
}
void Game::PInfo()
{
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	Character.ShowPlayerDetail();
	system("pause");
}
void Game::MInfo()
{
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	Character.ShowMonsterDetail();
	system("pause");
}
void Game::DongeonPage()
{ 
	Character.Fight(Character.EnemySelect());
}
void Game::NewGame()
{
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	DrawManager.DrawMidText("Player Name Set : ", WIDTH, HEIGHT * 0.5);
	Character.SetPlayerName();
	MenuPage();
}
void Game::LoadGame()
{
	Character.Load();
	MenuPage();
}
void Game::WeaponePage()
{
	int iSelect;
	while (1)
	{
		system("cls");
		DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		DrawManager.DrawMidText("�ڡڡ� WEAPON SHOP �ڡڡ�", WIDTH, HEIGHT * 0.1);
		DrawManager.DrawMidText("DAGGER", WIDTH, HEIGHT*0.2);
		DrawManager.DrawMidText("GUN", WIDTH, HEIGHT*0.3);
		DrawManager.DrawMidText("SWORD", WIDTH, HEIGHT*0.4);
		DrawManager.DrawMidText("WAND", WIDTH, HEIGHT*0.5);
		DrawManager.DrawMidText("BOW", WIDTH, HEIGHT*0.6);
		DrawManager.DrawMidText("HAMMER", WIDTH, HEIGHT*0.7);
		DrawManager.DrawMidText("BACK", WIDTH, HEIGHT*0.8);
		iSelect = DrawManager.MenuSelectCursor(7, 3, 10, HEIGHT*0.2);

		switch (iSelect)
		{
		case WDagger:
			system("cls");
			tmp = new Dagger;
			tmp->Draw();
			break;
		case WGun:
			system("cls");
			tmp = new Gun;
			tmp->Draw();
			break;
		case WSword:
			system("cls");
			tmp = new Sword;
			tmp->Draw();
			break;
		case WWand:
			system("cls");
			tmp = new Wand;
			tmp->Draw();
			break;
		case WBow:
			system("cls");
			tmp = new Bow;
			tmp->Draw();
			break;
		case WHammer:
			system("cls");
			tmp = new Hammer;
			tmp->Draw();
			break;
		case 7:
			return;
		default:
			break;
		}
	}
}

Game::~Game()
{
}
