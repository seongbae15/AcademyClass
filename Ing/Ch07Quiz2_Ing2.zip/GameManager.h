#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include "Board.h"
#include "Player.h"
class GameManager
{
private:
	Board m_board;
	Player m_player[2];
public:
	void Init(HWND hWnd);
	void DrawChessBoard(HDC hdc);
	void DrawPlayerPiece(HDC hdc);
};

