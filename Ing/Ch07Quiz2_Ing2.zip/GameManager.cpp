#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	//�̹��� �ҷ�����
	m_board.InitBoard(hWnd);
	m_player[WHITE].InitPlayer(hWnd,WHITE);
	m_player[BLACK].InitPlayer(hWnd,BLACK);
	//�ǽ� ��ġ �ʱ� ����
}

void GameManager::DrawChessBoard(HDC hdc)
{
	m_board.DrawBoard(hdc);
}

void GameManager::DrawPlayerPiece(HDC hdc)
{
	m_player[WHITE].DrawAllPiece(hdc);
	m_player[BLACK].DrawAllPiece(hdc);

}