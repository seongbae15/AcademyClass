#pragma once
#include "PlayLib.h"
#include "Piece.h"

class Player
{
private:
	Piece *m_Piece[PIECES_SIZE];
	//
public:
	void InitPlayer(HWND hWnd, int Player);
	void DrawAllPiece(HDC hdc);
};

