#pragma once
#include "PlayLib.h"
#include "Bitmap.h"

enum PIECES
{
	PIECES_START = 0,
	PIECES_PAWN1 = 0,
	PIECES_PAWN2,
	PIECES_PAWN3,
	PIECES_PAWN4,
	PIECES_PAWN5,
	PIECES_PAWN6,
	PIECES_PAWN7,
	PIECES_PAWN8,
	PIECES_KNIGHT1,
	PIECES_KNIGHT2,
	PIECES_BISHOP1,
	PIECES_BISHOP2,
	PIECES_ROOK1,
	PEICES_ROOK2,
	PIECES_QUEEN,
	PIECES_KING,
	PIECES_SIZE,
};

struct Position
{
	int iX;
	int iY;
};

class Piece
{
protected:
	Position m_stPos;
	bool m_bLive;
	Bitmap m_pieceBitmap;
	SIZE m_pieceImgSize;
public:
	virtual void InitPiece(HWND hWnd, int Player) = 0;
	virtual void SetInitPos(int Player,int nth)=0;
	void DrawPiece(HDC hdc);
	//virtual void MovePiece() = 0;
};

class Pawn : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player,int nth);
};

class Knight : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
};

class Bishop : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
};

class Rook : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
};

class Queen : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
};

class King : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
};