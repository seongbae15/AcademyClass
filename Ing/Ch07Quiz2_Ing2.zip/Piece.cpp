#include "Piece.h"

void Piece::DrawPiece(HDC hdc)
{
	if(m_bLive == true)
		m_pieceBitmap.Draw(hdc, m_stPos.iX, m_stPos.iY, IMG_RATE, IMG_RATE);
}

void Pawn::InitPiece(HWND hWnd,int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_00.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Pawn::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + nth * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 6 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 1 * IMG_RATE;
}

void Knight::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_01.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Knight::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (5 * nth + 1) * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 0 * IMG_RATE;
}

void Bishop::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_02.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Bishop::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (3 * nth + 2) * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 0 * IMG_RATE;
}

void Rook::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_03.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Rook::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (7 * nth) * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 0 * IMG_RATE;
}

void Queen::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_04.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Queen::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (nth + 3) * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 0 * IMG_RATE;
}

void King::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_05.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_pieceImgSize = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void King::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (nth + 4) * m_pieceImgSize.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_pieceImgSize.cy * 0 * IMG_RATE;
}