#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_board.InitBoard(hWnd);
	m_player[WHITE].InitPlayer(hWnd,WHITE);
	m_player[BLACK].InitPlayer(hWnd,BLACK);
}

void GameManager::DrawChessBoard(HDC hdc)
{
	m_board.DrawBoard(hdc);
}

void GameManager::DrawPlayerPiece(HDC hdc)
{
	m_player[WHITE].DrawAllPiece(hdc);
	m_player[BLACK].DrawAllPiece(hdc);
}

bool GameManager::SelectPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	
	int iSize = m_player[m_iTurn % 2].GetPieceVecSize();
	for (int i = 0; i < iSize;i++)
	{
		m_rectSelected = m_player[m_iTurn % 2].GetNthPieceRect(i);
		if (PtInRect(&m_rectSelected, ptMouse))
		{
			m_iSelectedPieceNum = i;
			InvalidateRect(hWnd, &m_rectSelected, true);
			return true;
		}
	}
	return false;

	//for (int i = PIECES_START;i < PIECES_SIZE;i++)
	//{
	//	RECT rectPiece = m_player[m_iTurn % 2].GetNthPieceRect(i);
	//	if (PtInRect(&rectPiece, ptMouse))
	//	{
	//		m_iSelectedPieceNum = i;
	//		InvalidateRect(hWnd, &rectPiece, true);
	//		return true;
	//	}
	//}
	//return false;
}

void GameManager::MovePlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	RECT rectPiece = m_player[m_iTurn % 2].GetNthPieceRect(m_iSelectedPieceNum);
	m_player[m_iTurn % 2].MovePiece(m_iSelectedPieceNum, ptMouse);	
	InvalidateRect(hWnd, &rectPiece, true);
}

//bool GameManager::CheckCheck(int index)
//{
//	bool bCheckState = false;
//	bool bCheckOwn = false;
//
//	std::vector<RECT>* pTmpRECT = m_player[m_iTurn % 2].GetAllMove(index);
//	for (int i = 0; i < 8; i++)
//	{
//		if (index <= PIECES_PAWN8)
//		{
//			if (m_iTurn % 2 == WHITE)
//			{
//				if (i == MOVE_DIR_TOP_LEFT || i == MOVE_DIR_TOP_RIGHT)
//					bCheckOwn = false;
//				else
//					bCheckOwn = true;
//			}
//			else if (m_iTurn % 2 == BLACK)
//			{
//				if (i == MOVE_DIR_DOWN_LEFT || i == MOVE_DIR_DOWN_RIGHT)
//					bCheckOwn = false;
//				else
//					bCheckOwn = true;
//			}
//		}
//		else
//			bCheckOwn = false;
//		int iSize = pTmpRECT[i].size();
//		for (int j = 0; j < iSize; j++)
//		{
//			POINT pointTmp = { pTmpRECT[i][j].left, pTmpRECT[i][j].top };
//			//ŷ�� ã�����, ���� �� ��� �ٸ� ���� ��ġ�� �ʴ��� Ȯ��
//			//���� ��
//			if (bCheckOwn == false)
//			{
//				for (int k = PIECES_START; k < PIECES_SIZE; k++)
//				{
//					RECT rectPiece = m_player[m_iTurn % 2].GetPiecePosition(k);
//					if (PtInRect(&rectPiece, pointTmp))
//					{
//						//�ش� ���� �˻�X
//						//���� �������� �Ѿ��
//						bCheckOwn = true;
//						break;
//					}
//				}
//
//			}
//			//ŷ�� ã�����, ���� �� ��� �ٸ� ���� ��ġ�� �ʴ��� Ȯ��
//			//��� ��
//			if (bCheckOwn == false)
//			{
//				for (int k = PIECES_START; k < PIECES_SIZE; k++)
//				{
//					RECT rectPiece = m_player[(m_iTurn+1) % 2].GetPiecePosition(k);
//					if (PtInRect(&rectPiece, pointTmp))
//					{
//						//��ġ�� ���, ŷ���� Ȯ��
//						//ŷ�̸� üũ, ����
//						if (m_player[(m_iTurn + 1) % 2].GetSelectedType(k) == "King")
//						{
//							bCheckState = true;
//							return bCheckState;
//						}
//						else
//						{
//							bCheckOwn = true;
//							break;
//						}
//					}
//					//ŷ�� �����ϼ� �ִ� ��ġ ��?.
//				}
//			}
//			if (bCheckOwn == true)
//				break;
//		}
//	}
//	return bCheckState;
//}
//bool GameManager::CheckCheckMate()
//{
//	//��� ŷ�� ������ �� �ִ� ��ġ �ҷ�����
//	std::vector<RECT>* pTmpRECT = m_player[(m_iTurn + 1) % 2].GetAllMove(PIECES_KING);
//	//�ش� ��ġ�� ���� ���� ���� ��� ������ ������ �κп� ���� ��ġ���� Ȯ��
//	bool bChecker;
//	for (int i = 0;i < PIECES_SIZE;i++)
//	{
//		bChecker = CheckCheck(i);
//		if (bChecker == true)
//			break;
//	}
//	return bChecker;
//}

bool GameManager::FindCheck(int index)
{
	std::vector<RECT>* possibleRect = m_player[m_iTurn % 2].GetAllMove(index);

}

bool GameManager::FindCheckMate()
{

}

int GameManager::CheckGameEnd()
{
	if (FindCheck(m_iSelectedPieceNum))
	{
		if (FindCheckMate())
			return GAME_END_CHECKMATE;
		return GAME_END_CHECK;
	}
	return GAME_END_NONE;
}


void GameManager::DropPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);

	bool bCheckPos = CheckDropPossible(ptMouse);
	if (bCheckPos)
	{
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2);
		//üũ,üũ����Ʈ Ȯ��
		switch (CheckGameEnd())
		{
		case GAME_END_NONE:
			break;
		case GAME_END_CHECK:
			MessageBox(hWnd, TEXT("Check!!!"), TEXT("Alaram"), MB_OK);
			break;
		case GAME_END_CHECKMATE:
			MessageBox(hWnd, TEXT("CheckMate!!!"), TEXT("Alaram"), MB_OKCANCEL);
			break;
		}
		m_iTurn++;

		//if (CheckCheck(m_iSelectedPieceNum))
		//{
		//	if (CheckCheckMate())
		//	{
		//		//üũ ����Ʈ, �޽��� �ڽ� �߻�
		//		MessageBox(hWnd, TEXT("CheckMate!!!"), TEXT("Alaram"), MB_OKCANCEL);

		//	}
		//	else
		//	{
		//		//üũ �޽��� �ڽ� �߻�
		//		MessageBox(hWnd, TEXT("Check!!!"), TEXT("Alaram"), MB_OK);
		//	}
		//}
	}
	else
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2,bCheckPos);
	InvalidateRect(hWnd, NULL, true);
}

bool GameManager::CheckPoint(RECT* rect, POINT point)
{
	if (PtInRect(rect, point))
		return true;
	else
		return false;
}

bool GameManager::CheckPawnMove(int move_dir,int mode)
{
	bool bCheckPawn = true;
	if (m_iTurn % 2 == WHITE)
	{
		if (move_dir == MOVE_DIR_TOP)
			bCheckPawn = true;
		else
			bCheckPawn = false;
	}
	else if (m_iTurn % 2 == BLACK)
	{
		if (move_dir == MOVE_DIR_DOWN)
			bCheckPawn = true;
		else
			bCheckPawn = false;
	}
	if (mode == PAWN_DROP_NONE)
		return bCheckPawn;
	else
		return !bCheckPawn;

}

bool GameManager::CheckDropPossible(POINT mousePt)
{
	bool bCheckPos = true;
	//���õ� �ǽ��� ����, ������ ������ ��ġ�� ��������
	std::vector<RECT>* possibleRect = m_player[m_iTurn % 2].GetAllMove(m_iSelectedPieceNum);
	std::vector<RECT> checkRectVec;
	int iSelectedDir;
	for (int i = 0; i < DIR_COUNT; i++)
	{
		int iSize = possibleRect[i].size();
		for (int j = 0; j < iSize; j++)
		{
			if (CheckPoint(&possibleRect[i][j], mousePt))
			{
				checkRectVec = possibleRect[i];
				iSelectedDir = i;
				break;
			}
			//if (PtInRect(&possibleRect[i][j], mousePt))
			//{
			//	checkRectVec = possibleRect[i];
			//	break;
			//}
		}
	}
	if (checkRectVec.empty())
		return false;
	else
	{
		int iSizeCount = checkRectVec.size();
		for (int i = 0; i < iSizeCount; i++)
		{
			//���� �� ��ġ �浹 �˻� (�̵� ������ ��ġ - ���� �� ��ġ)
			int iPieceCount = m_player[m_iTurn % 2].GetPieceVecSize();
			for (int j = 0; j < iPieceCount; j++)
			{
				RECT tmpRect = m_player[m_iTurn % 2].GetNthPieceRect(j);
				POINT searchPoint = { tmpRect.left, tmpRect.top };
				if (CheckPoint(&checkRectVec[i], searchPoint))
				{
					return false;
				}
				//POINT GET
			}
			//��� �� ��ġ �浹 �˻� (���콺 ������ - ��� �� ��ġ)
			iPieceCount = m_player[(m_iTurn + 1) % 2].GetPieceVecSize();
			for (int j = 0; j < iPieceCount; j++)
			{
				RECT tmpRect = m_player[(m_iTurn+1) % 2].GetNthPieceRect(j);
				POINT searchPoint = { tmpRect.left, tmpRect.top };
				if (CheckPoint(&checkRectVec[i], searchPoint))
				{
					if (CheckPoint(&checkRectVec[i], mousePt))
					{
						if (m_player[m_iTurn % 2].GetSelectedPieceType(m_iSelectedPieceNum) == PIECE_TYPE_PAWN)
						{
							return CheckPawnMove(iSelectedDir, PAWN_DROP_EAT);
							//if (m_iTurn % 2 == WHITE)
							//{
							//	if (iSelectedDir == MOVE_DIR_TOP)
							//		return false;
							//	else
							//		return true;
							//}
							//else if (m_iTurn % 2 == BLACK)
							//{
							//	if (iSelectedDir == MOVE_DIR_DOWN)
							//		return false;
							//	else
							//		return true;
							//}
						}
						else
							return true;
					}
					else
						return false;
				}
			}
			//�� ���� �δ� �� üũ
			if (CheckPoint(&checkRectVec[i], mousePt))
			{
				if (m_player[m_iTurn % 2].GetSelectedPieceType(m_iSelectedPieceNum) == PIECE_TYPE_PAWN)
				{
					return CheckPawnMove(iSelectedDir, PAWN_DROP_NONE);
					//if (m_iTurn % 2 == WHITE)
					//{
					//	if (iSelectedDir == MOVE_DIR_TOP)
					//		return true;
					//	else
					//		return false;
					//}
					//else if (m_iTurn % 2 == BLACK)
					//{
					//	if (iSelectedDir == MOVE_DIR_DOWN)
					//		return true;
					//	else
					//		return false;
					//}
				}
				else
					return true;
			}
		}
	}


	//std::vector<RECT> checkRect = m_player[m_iTurn % 2].CheckPlayerPieceMove(m_iSelectedPieceNum, mousePt);
	//if (checkRect.size() == 0)
	//	bCheckPos = false;
	//else
	//{
	//	int iCount = checkRect.size();
	//	for (int i = 0; i < iCount; i++)
	//	{
	//		// �ڱ⸻ ��ġ �˻�
	//		for (int j = 0; j < PIECES_SIZE; j++)
	//		{
	//			if (j == m_iSelectedPieceNum)
	//				continue;
	//			RECT tmpRect = m_player[m_iTurn % 2].GetNthPieceRect(j);
	//			if (checkRect[i].top == tmpRect.top && checkRect[i].left == tmpRect.left)
	//			{
	//				bCheckPos = false;
	//				return bCheckPos;
	//			}
	//		}
	//		// ��븻 ��ġ �˻�
	//		for (int k = 0; k < PIECES_SIZE; k++)
	//		{
	//			RECT tmpRect2 = m_player[(m_iTurn+1) % 2].GetNthPieceRect(k);
	//			if (checkRect[i].top == tmpRect2.top && checkRect[i].left == tmpRect2.left)
	//			{
	//				if (PtInRect(&checkRect[i], mousePt))
	//				{
	//					//���� ���, ���� ��Ģ ���ϱ�
	//					if (m_iSelectedPieceNum <= PIECES_PAWN8)
	//					{
	//						if (m_iTurn % 2 == WHITE)
	//						{
	//							if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_TOP)
	//								bCheckPos = false;
	//							else
	//								bCheckPos = true;
	//						}
	//						else if (m_iTurn % 2 == BLACK)
	//						{
	//							if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_DOWN)
	//								bCheckPos = false;
	//							else
	//								bCheckPos = true;
	//						}
	//					}
	//					else
	//						bCheckPos = true;
	//					if (bCheckPos == true)
	//					{
	//						m_player[(m_iTurn + 1) % 2].DiePiece(k);
	//					}
	//					return bCheckPos;
	//				}
	//				bCheckPos = false;
	//				return bCheckPos;
	//			}
	//		}
	//		//�� ���� �� ��,
	//		if (PtInRect(&checkRect[i], mousePt))
	//		{
	//			//���� ���, ���� ��Ģ ���ϱ�
	//			if (m_iSelectedPieceNum <= PIECES_PAWN8)
	//			{
	//				if (m_iTurn % 2 == WHITE)
	//				{
	//					if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_TOP)
	//						bCheckPos = true;
	//					else
	//						bCheckPos = false;
	//				}
	//				else if (m_iTurn % 2 == BLACK)
	//				{
	//					if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_DOWN)
	//						bCheckPos = true;
	//					else
	//						bCheckPos =  false;
	//				}
	//			}
	//			else
	//				bCheckPos = true;
	//			return bCheckPos;
	//		}
	//	}
	//}
	//return bCheckPos;
}