#pragma once
#include "PlayLib.h"
#include "Piece.h"

class Player
{
private:
	Piece *m_Piece[PIECES_SIZE];
	int m_iSelectedMoveDir;

	std::vector<Piece*> m_vecPiece;
	int m_iInitPieceCount;


public:
	void InitPlayer(HWND hWnd, int player_type);
	void InitEachPiece(HWND hWnd, int player_type, int piece_type);
	void DrawAllPiece(HDC hdc);
	void MovePiece(int index, POINT mousePt);
	void DropPiece(int index, POINT mousePt, int player_type, bool move_state = true);
	

	inline int GetPieceVecSize()
	{
		return m_vecPiece.size();
	}
	inline RECT GetNthPieceRect(int index)
	{
		return m_vecPiece[index]->GetPieceRect();
		//return m_Piece[index]->GetPieceRect();
	}
	inline std::vector<RECT>* GetAllMove(int index)
	{
		return m_vecPiece[index]->GetPossibleMoveAll();
		//return m_Piece[index]->GetPossibleMoveAll();
	}
	inline int GetSelectedPieceType(int index)
	{
		return m_vecPiece[index]->GetType();
	}


	//������
	//inline RECT GetPiecePosition(int index)
	//{
	//	return m_Piece[index]->GetPieceRect();
	//}
	//std::vector<RECT> CheckPlayerPieceMove(int index, POINT mousePt);
	//std::vector<RECT> GetPossibleMoveRectVec(int index, POINT mousePt);
	//�����
	//void DiePiece(int index);
	inline std::string GetSelectedType(int index)
	{
		return m_Piece[index]->GetPiecetype();
	}
	inline int GetSelectiedDirection()
	{
		return m_iSelectedMoveDir;
	}

};