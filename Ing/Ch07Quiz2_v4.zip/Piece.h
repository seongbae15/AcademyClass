#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include <vector>

enum PIECES
{
	PIECES_START = 0,
	PIECES_PAWN1 = 0,
	PIECES_PAWN2,
	PIECES_PAWN3,
	PIECES_PAWN4,
	PIECES_PAWN5,
	PIECES_PAWN6,
	PIECES_PAWN7,
	PIECES_PAWN8,
	PIECES_KNIGHT1,
	PIECES_KNIGHT2,
	PIECES_BISHOP1,
	PIECES_BISHOP2,
	PIECES_ROOK1,
	PEICES_ROOK2,
	PIECES_QUEEN,
	PIECES_KING,
	PIECES_SIZE,
};


enum MOVE_DIR
{
	MOVE_DIR_START = 0,
	MOVE_DIR_TOP = 0,
	MOVE_DIR_TOP_LEFT,
	MOVE_DIR_LEFT,
	MOVE_DIR_DOWN_LEFT,
	MOVE_DIR_DOWN,
	MOVE_DIR_DOWN_RIGHT,
	MOVE_DIR_RIGHT,
	MOVE_DIR_TOP_RIGHT,
	MOVE_DIR_END,
};

struct Position
{
	int iX;
	int iY;
};

class Piece
{
protected:
	bool m_bLive;
	Bitmap m_pieceBitmap;
	SIZE m_sizePieceImg;

	Position m_stPos;
	Position m_stLastPos;
	RECT m_rectPiece;
	std::vector<Position> m_vecPossibleMovePos;
	std::vector<RECT> m_vecRectPossibleMove;
	std::vector<RECT> m_vecRectPossibleMove2[8];
	bool m_bFirstMove;
public:
	virtual void InitPiece(HWND hWnd, int Player) = 0;
	virtual void SetInitPos(int Player,int nth)=0;
	void DrawPiece(HDC hdc);
	void Move(POINT mousePt);
	void Drop(POINT mousePt,bool move_state = true, int Player=WHITE);
	RECT SetImgRect(int x, int y);
	virtual void SetPossibleMove(int player= WHITE) =0;
	virtual void ShowMove(int player) = 0;
	void ReleaseShowMove();
	inline RECT GetPieceRect()
	{
		return m_rectPiece;
	}
	inline RECT GetPossibleRect(int index)
	{
		if (m_vecRectPossibleMove.empty())
			return m_rectPiece;
		return m_vecRectPossibleMove[index];
	}
	inline RECT GetPossibleRect2(int dir_move, int index)
	{
		if (m_vecRectPossibleMove2[dir_move].empty())
			return m_rectPiece;
		return m_vecRectPossibleMove2[dir_move][index];
	}
	inline std::vector<RECT> GetPossibleRectArr(int dir_move)
	{
		//if (m_vecRectPossibleMove2[dir_move].empty())
		//	return m_rectPiece;
		return m_vecRectPossibleMove2[dir_move];
	}
	inline int GetSizePossibleMove()
	{
		return m_vecRectPossibleMove.size();
	}
	inline int GetSizePossibleMove2(int dir_move)
	{
		return m_vecRectPossibleMove2[dir_move].size();
	}
	//virtual void MovePiece() = 0;
};

class Pawn : public Piece
{
private:

public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player,int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};

class Knight : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};

class Bishop : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};

class Rook : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};

class Queen : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};

class King : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void SetPossibleMove(int player);
	void ShowMove(int player) {};
};