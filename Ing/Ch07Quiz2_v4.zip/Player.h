#pragma once
#include "PlayLib.h"
#include "Piece.h"

class Player
{
private:
	Piece *m_Piece[PIECES_SIZE];
	//
public:
	void InitPlayer(HWND hWnd, int Player);
	void DrawAllPiece(HDC hdc);
	void MovePiece(int index, POINT mousePt);
	void DropPiece(int index, POINT mousePt, bool move_state = true, int Player = WHITE);
	void ShowPossiblePieceMove(int player, int index);
	void ReleaseShowPieceMove(int index);
	std::vector<RECT> CheckPlayerPieceMove(int index, POINT mousePt);
	inline RECT GetPiecePosition(int index)
	{
		return m_Piece[index]->GetPieceRect();
	}
};