#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include "Board.h"
#include "Player.h"
class GameManager
{
private:
	Board m_board;
	Player m_player[2];
	int m_iTurn;
	int m_iSelectPieceNum;
public:
	void Init(HWND hWnd);
	void DrawChessBoard(HDC hdc);
	void DrawPlayerPiece(HDC hdc);
	bool SelectPlayerPiece(HWND hWnd, LPARAM lParam);
	void MovePlayerPiece(HWND hWnd, LPARAM lParam);
	void DropPlayerPiece(HWND hWnd, LPARAM lParam);
	void CheckChessRull(int index);
	void ShowPossibleMove(HWND hWnd, LPARAM lParam);
	void ReleasePossibleMove(HWND hWnd);
	bool CheckDropPossible(POINT pos);
};

