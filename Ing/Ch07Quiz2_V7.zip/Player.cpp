#include "Player.h"

void Player::InitEachPiece(HWND hWnd, int player_type, int piece_type)
{
	//�� �Ʒ� ���� �Լ�ȭ, ���� ���θ�� �۾� ��
	Piece* tmpPiece = NULL;
	switch ((PIECE_TYPE)piece_type)
	{
	case PIECE_TYPE_PAWN:
		tmpPiece = new Pawn;
		break;
	case PIECE_TYPE_KNIGHT:
		tmpPiece = new Knight;
		break;
	case PIECE_TYPE_BISHOP:
		tmpPiece = new Bishop;
		break;
	case PIECE_TYPE_ROOK:
		tmpPiece = new Rook;
		break;
	case PIECE_TYPE_QUEEN:
		tmpPiece = new Queen;
		break;
	case PIECE_TYPE_KING:
		tmpPiece = new King;
		break;
	}
	tmpPiece->InitPiece(hWnd, player_type, piece_type);
	tmpPiece->SetInitEachPos(player_type, m_iInitPieceCount);
	m_vecPiece.push_back(tmpPiece);
}

void Player::InitPlayer(HWND hWnd, int Player)
{
	m_iInitPieceCount = 0;
	for (int i = PIECE_TYPE_PAWN;i <= PIECE_TYPE_KING;)
	{
		InitEachPiece(hWnd, Player, i);
		m_iInitPieceCount++;
		if (i == PIECE_TYPE_PAWN)
		{
			if (m_iInitPieceCount == INIT_PAWN_COUNT)
			{
				i++;
				m_iInitPieceCount = 0;
			}
		}
		else if (i <= PIECE_TYPE_ROOK)
		{
			if (m_iInitPieceCount == INIT_KBR_COUNT)
			{
				i++;
				m_iInitPieceCount = 0;
			}
		}
		else
		{
			i++;
			m_iInitPieceCount = 0;
		}
	}
}

void Player::DrawAllPiece(HDC hdc)
{
	for (int i = 0;i < m_vecPiece.size();i++)
	{
		m_vecPiece[i]->DrawPiece(hdc);
	}
}

void Player::MovePiece(int index,POINT mousePt)
{
	m_vecPiece[index]->Move(mousePt);
}

void Player::DropPiece(int index, POINT mousePt, int player_type, bool move_state)
{
	m_vecPiece[index]->Drop(mousePt, player_type, move_state);
}



//std::vector<RECT> Player::GetPossibleMoveRectVec(int index, POINT mousePt)
//{
//	std::vector<RECT> vecTmpRect;
//	for (int iMove = 0; iMove < DIR_COUNT; iMove++)
//	{
//		int iSize;
//		for (int j = 0; j < m_Piece[index]->GetSizePossibleMove2(iMove); j++)
//		{
//			RECT rectTmp2 = m_Piece[index]->GetPossibleRect2(iMove, j);
//			if (PtInRect(&rectTmp2, mousePt))
//			{
//				m_iSelectedMoveDir = iMove;
//				vecTmpRect = m_Piece[index]->GetPossibleRectArr(iMove);
//				return vecTmpRect;
//			}
//
//		}
//	}
//
//}
//
//std::vector<RECT> Player::CheckPlayerPieceMove(int index,POINT mousePt)
//{
//	std::vector<RECT> vecTmpRect;
//	for (int iMove = 0; iMove < DIR_COUNT; iMove++)
//	{
//		for (int j = 0; j < m_Piece[index]->GetSizePossibleMove2(iMove); j++)
//		{
//			RECT rectTmp2 = m_Piece[index]->GetPossibleRect2(iMove,j);
//			if (PtInRect(&rectTmp2, mousePt))
//			{
//				m_iSelectedMoveDir = iMove;
//				vecTmpRect = m_Piece[index]->GetPossibleRectArr(iMove);
//				return vecTmpRect;
//			}
//
//		}
//	}
//}
//
//void Player::DiePiece(int index)
//{
//	m_Piece[index]->Die();
//}