#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_board.InitBoard(hWnd);
	m_player[WHITE].InitPlayer(hWnd,WHITE);
	m_player[BLACK].InitPlayer(hWnd,BLACK);
}

void GameManager::DrawChessBoard(HDC hdc)
{
	m_board.DrawBoard(hdc);
}

void GameManager::DrawPlayerPiece(HDC hdc)
{
	m_player[WHITE].DrawAllPiece(hdc);
	m_player[BLACK].DrawAllPiece(hdc);
}

bool GameManager::SelectPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	
	int iSize = m_player[m_iTurn % 2].GetPieceVecSize();
	for (int i = 0; i < iSize;i++)
	{
		m_rectSelected = m_player[m_iTurn % 2].GetNthPieceRect(i);
		if (PtInRect(&m_rectSelected, ptMouse))
		{
			m_iSelectedPieceNum = i;
			InvalidateRect(hWnd, &m_rectSelected, true);
			return true;
		}
	}
	return false;
}

void GameManager::MovePlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	RECT rectPiece = m_player[m_iTurn % 2].GetNthPieceRect(m_iSelectedPieceNum);
	m_player[m_iTurn % 2].MovePiece(m_iSelectedPieceNum, ptMouse);	
	InvalidateRect(hWnd, &rectPiece, true);
}

bool GameManager::FindCheck(int index)
{
	std::vector<RECT>* possibleRect = m_player[m_iTurn % 2].GetAllMove(index);
	for (int i = 0; i < DIR_COUNT; i++)
	{
		bool bCheckPiece = false;
		if (m_player[m_iTurn % 2].GetSelectedPieceType(index) == PIECE_TYPE_PAWN)
			bCheckPiece = CheckPawnMove(i, PAWN_DROP_NONE);
		if (bCheckPiece == false)
		{
			int iLoopSize = possibleRect[i].size();
			for (int j = 0; j < iLoopSize; j++)
			{
				//���� �� �˻�
				if (CheckOwnAllPiece(&possibleRect[i][j]))
					break;
				//���� �� �˻�
				int iOtherPieceCount = m_player[(m_iTurn + 1) % 2].GetPieceVecSize();
				for (int k = 0; k < iOtherPieceCount; k++)
				{
					RECT tmpRect = m_player[(m_iTurn + 1) % 2].GetNthPieceRect(k);
					POINT searchPoint = { tmpRect.left, tmpRect.top };
					if (CheckPoint(&possibleRect[i][j], searchPoint))
					{
						if (m_player[(m_iTurn + 1) % 2].GetSelectedPieceType(k) == PIECE_TYPE_KING)
							return true;
						else
						{
							bCheckPiece = true;
							break;
						}
					}
				}
				if (bCheckPiece == true)
					break;
			}
		}
	}
	return false;
}

bool GameManager::FindCheckMate()
{
	return false;
}

int GameManager::CheckGameEnd()
{
	if (FindCheck(m_iSelectedPieceNum))
	{
		if (FindCheckMate())
			return GAME_END_CHECKMATE;
		else
			return GAME_END_CHECK;
	}
	else
		return GAME_END_NONE;
}


void GameManager::DropPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);

	bool bCheckPos = CheckDropPossible(ptMouse);
	if (bCheckPos)
	{
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2);
		//üũ,üũ����Ʈ Ȯ��
		switch (CheckGameEnd())
		{
		case GAME_END_NONE:
			break;
		case GAME_END_CHECK:
			MessageBox(hWnd, TEXT("Check!!!"), TEXT("Alaram"), MB_OK);
			break;
		case GAME_END_CHECKMATE:
			MessageBox(hWnd, TEXT("CheckMate!!!"), TEXT("Alaram"), MB_OKCANCEL);
			//���� �۾� �ۼ�
			break;
		}
		m_iTurn++;
	}
	else
		m_player[m_iTurn % 2].DropPiece(m_iSelectedPieceNum, ptMouse, m_iTurn % 2,bCheckPos);
	InvalidateRect(hWnd, NULL, true);
}

bool GameManager::CheckPoint(RECT* rect, POINT point)
{
	if (PtInRect(rect, point))
		return true;
	else
		return false;
}

bool GameManager::CheckPawnMove(int move_dir,int mode)
{
	bool bCheckPawn = true;
	if (m_iTurn % 2 == WHITE)
	{
		if (move_dir == MOVE_DIR_TOP)
			bCheckPawn = true;
		else if(move_dir == MOVE_DIR_TOP_LEFT || move_dir == MOVE_DIR_TOP_RIGHT)
			bCheckPawn = false;
	}
	else if (m_iTurn % 2 == BLACK)
	{
		if (move_dir == MOVE_DIR_DOWN)
			bCheckPawn = true;
		else if (move_dir == MOVE_DIR_DOWN_LEFT || move_dir == MOVE_DIR_DOWN_RIGHT)
			bCheckPawn = false;
	}
	if (mode == PAWN_DROP_NONE)
		return bCheckPawn;
	else if(mode == PAWN_DROP_CATCH)
		return !bCheckPawn;
}

bool GameManager::CheckOwnAllPiece(RECT* pRect)
{
	int iPieceCount = m_player[m_iTurn % 2].GetPieceVecSize();
	for (int j = 0; j < iPieceCount; j++)
	{
		if (j == m_iSelectedPieceNum)
			continue;
		RECT tmpRect = m_player[m_iTurn % 2].GetNthPieceRect(j);
		POINT searchPoint = { tmpRect.left, tmpRect.top };
		if (CheckPoint(pRect, searchPoint))
			return true;
	}
	return false;
}

bool GameManager::CheckDropPossible(POINT mousePt)
{
	bool bCheckPos = true;
	//���õ� �ǽ��� ����, ������ ������ ��ġ�� ��������
	std::vector<RECT>* possibleRect = m_player[m_iTurn % 2].GetAllMove(m_iSelectedPieceNum);
	std::vector<RECT> checkRectVec;
	int iSelectedDir;
	for (int i = 0; i < DIR_COUNT; i++)
	{
		int iSize = possibleRect[i].size();
		for (int j = 0; j < iSize; j++)
		{
			if (CheckPoint(&possibleRect[i][j], mousePt))
			{
				checkRectVec = possibleRect[i];
				iSelectedDir = i;
				break;
			}
		}
	}
	if (checkRectVec.empty())
		return false;
	else
	{
		int iSizeCount = checkRectVec.size();
		for (int i = 0; i < iSizeCount; i++)
		{
			//���� �� ��ġ �浹 �˻� (�̵� ������ ��ġ - ���� �� ��ġ)
			if (CheckOwnAllPiece(&checkRectVec[i]))
				return false;

			//��� �� ��ġ �浹 �˻� (���콺 ������ - ��� �� ��ġ)
			int iPieceCount = m_player[(m_iTurn + 1) % 2].GetPieceVecSize();
			for (int j = 0; j < iPieceCount; j++)
			{
				RECT tmpRect = m_player[(m_iTurn+1) % 2].GetNthPieceRect(j);
				POINT searchPoint = { tmpRect.left, tmpRect.top };
				if (CheckPoint(&checkRectVec[i], searchPoint))
				{
					if (CheckPoint(&checkRectVec[i], mousePt))
					{
						if (m_player[m_iTurn % 2].GetSelectedPieceType(m_iSelectedPieceNum) == PIECE_TYPE_PAWN)
							return CheckPawnMove(iSelectedDir, PAWN_DROP_CATCH);
						else
							return true;
					}
					else
						return false;
				}
			}
			//�� ���� �δ� �� üũ
			if (CheckPoint(&checkRectVec[i], mousePt))
			{
				if (m_player[m_iTurn % 2].GetSelectedPieceType(m_iSelectedPieceNum) == PIECE_TYPE_PAWN)
					return CheckPawnMove(iSelectedDir, PAWN_DROP_NONE);
				else
					return true;
			}
		}
	}
}