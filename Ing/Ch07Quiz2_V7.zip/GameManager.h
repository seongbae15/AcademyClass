#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include "Board.h"
#include "Player.h"
class GameManager
{
private:
	Board m_board;
	Player m_player[2];
	int m_iTurn;
	int m_iSelectedPieceNum;
	RECT m_rectSelected;


	POINT m_pointSelectedPiece;

public:
	void Init(HWND hWnd);
	void DrawChessBoard(HDC hdc);
	void DrawPlayerPiece(HDC hdc);
	bool SelectPlayerPiece(HWND hWnd, LPARAM lParam);
	void MovePlayerPiece(HWND hWnd, LPARAM lParam);
	void DropPlayerPiece(HWND hWnd, LPARAM lParam);
	bool CheckDropPossible(POINT mousePt);
	bool CheckPoint(RECT* rect,POINT point);
	bool CheckPawnMove(int move_dir, int mode);
	int CheckGameEnd();
	bool FindCheck(int index);
	bool FindCheckMate();
	bool CheckOwnAllPiece(RECT* pRect);
};

