#include "Piece.h"

void Piece::DrawPiece(HDC hdc)
{
	if (m_bLive == true)
	{
		m_pieceBitmap.Draw(hdc, m_stPos.iX, m_stPos.iY, IMG_RATE, IMG_RATE);
		if (!m_vecPossibleMovePos.empty())
		{
			for (int i = 0;i < m_vecPossibleMovePos.size();i++)
			{
				//�׵θ� �׸���
				//
				m_pieceBitmap.Draw(hdc, m_vecPossibleMovePos[i].iX, m_vecPossibleMovePos[i].iY, IMG_RATE, IMG_RATE);
			}
		}
	}
}

void Piece::SetImgRect()
{
	m_rectPiece = { m_stPos.iX ,m_stPos.iY ,(int)(m_stPos.iX + m_sizePieceImg.cx * IMG_RATE),(int)(m_stPos.iY + m_sizePieceImg.cy * IMG_RATE) };
}

void Piece::Move(POINT mousePt)
{
	//��ġ ���� ���� : Position, Rect ����
	m_stPos.iX = mousePt.x - m_sizePieceImg.cx * IMG_RATE * 0.5f;
	m_stPos.iY = mousePt.y - m_sizePieceImg.cy * IMG_RATE * 0.5f;
	SetImgRect();
}

void Piece::Drop(POINT mousePt, bool move_state)
{
	if (move_state == true)
	{
		int iTmpX = (mousePt.x - START_X) / (m_sizePieceImg.cx * IMG_RATE);
		int iTmpY = (mousePt.y - START_Y) / (m_sizePieceImg.cy * IMG_RATE);
		m_stPos.iX = START_X + m_sizePieceImg.cx * IMG_RATE * iTmpX;
		m_stPos.iY = START_Y + m_sizePieceImg.cy * IMG_RATE * iTmpY;
		m_bFirstMove = false;
		m_stLastPos = m_stPos;
	}
	else
	{
		m_stPos = m_stLastPos;
	}
	SetImgRect();
}

void Piece::ReleaseShowMove()
{
	m_vecPossibleMovePos.clear();
}

void Pawn::InitPiece(HWND hWnd,int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_00.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
	m_bFirstMove = true;
	
}

void Pawn::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + nth * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 6 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 1 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}

void Pawn::ShowMove(int player)
{
	Position tmpPos;
	int iLoopCount = 3;
	if (m_bFirstMove == true)
		iLoopCount = 2;
	for (int i = 1;i <= iLoopCount;i++)
	{
		if (player == WHITE)
		{
			tmpPos.iX = m_stPos.iX;
			tmpPos.iY = m_stPos.iY - i * m_sizePieceImg.cy * IMG_RATE;
		}
		else if (player == BLACK)
		{
			tmpPos.iX = m_stPos.iX;
			tmpPos.iY = m_stPos.iY + i * m_sizePieceImg.cy * IMG_RATE;
		}
		m_vecPossibleMovePos.push_back(tmpPos);
	}
	
}

void Knight::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_01.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Knight::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (5 * nth + 1) * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}

void Bishop::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_02.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Bishop::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (3 * nth + 2) * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}

void Rook::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_03.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Rook::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (7 * nth) * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}

void Queen::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_04.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void Queen::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (nth + 3) * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}

void King::InitPiece(HWND hWnd, int Player)
{
	char chBuf[256];
	char chPlayer;
	if (Player == WHITE)
		chPlayer = 'w';
	else if (Player == BLACK)
		chPlayer = 'b';
	HDC hdc = GetDC(hWnd);
	wsprintf(chBuf, "ResChess//block_%c_05.bmp", chPlayer);
	m_pieceBitmap.Init(hdc, TEXT(chBuf));
	ReleaseDC(hWnd, hdc);

	m_sizePieceImg = m_pieceBitmap.GetSize();
	m_bLive = true;
}

void King::SetInitPos(int Player, int nth)
{
	m_stPos.iX = START_X + (nth + 4) * m_sizePieceImg.cx * IMG_RATE;
	if (Player == WHITE)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 7 * IMG_RATE;
	else if (Player == BLACK)
		m_stPos.iY = START_Y + m_sizePieceImg.cy * 0 * IMG_RATE;
	SetImgRect();
	m_stLastPos = m_stPos;
}