#include "Player.h"

void Player::InitPlayer(HWND hWnd, int Player)
{
	for (int i = PIECES_START; i < PIECES_SIZE; i++)
	{
		int iNth = i;
		switch ((PIECES)i)
		{
		case PIECES_PAWN1:
		case PIECES_PAWN2:
		case PIECES_PAWN3:
		case PIECES_PAWN4:
		case PIECES_PAWN5:
		case PIECES_PAWN6:
		case PIECES_PAWN7:
		case PIECES_PAWN8:
			iNth -= PIECES_PAWN1;
			m_Piece[i] = new Pawn;
			break;
		case PIECES_KNIGHT1:
		case PIECES_KNIGHT2:
			iNth -= PIECES_KNIGHT1;
			m_Piece[i] = new Knight;
			break;
		case PIECES_BISHOP1:
		case PIECES_BISHOP2:
			iNth -= PIECES_BISHOP1;
			m_Piece[i] = new Bishop;
			break;
		case PIECES_ROOK1:
		case PEICES_ROOK2:
			iNth -= PIECES_ROOK1;
			m_Piece[i] = new Rook;
			break;
		case PIECES_QUEEN:
			iNth -= PIECES_QUEEN;
			m_Piece[i] = new Queen;
			break;
		case PIECES_KING:
			iNth -= PIECES_KING;
			m_Piece[i] = new King;
			break;
		default:
			break;
		}
		m_Piece[i]->InitPiece(hWnd, Player);
		m_Piece[i]->SetInitPos(Player,iNth);
	}
}

void Player::DrawAllPiece(HDC hdc)
{
	for (int i = PIECES_START; i < PIECES_SIZE; i++)
	{
		m_Piece[i]->DrawPiece(hdc);
	}
}

void Player::MovePiece(int index,POINT mousePt)
{
	m_Piece[index]->Move(mousePt);
}

void Player::DropPiece(int index, POINT mousePt, bool move_state)
{
	m_Piece[index]->Drop(mousePt,move_state);
}

void Player::ShowPossiblePieceMove(int player, int index)
{
	m_Piece[index]->ShowMove(player);
}

void Player::ReleaseShowPieceMove(int index)
{
	m_Piece[index]->ReleaseShowMove();
}

bool Player::CheckPlayerPieceMove(int index,POINT mousePt)
{
	return true;
}