#pragma once
#include <Windows.h>
#define IMG_SIZE 125
#define WINDOW_WIDTH 125*9
#define WINDOW_HEIGHT 125*9
#define IMG_RATE 0.6f

#define ROW 8
#define COL 8

#define WHITE 0
#define BLACK 1

#define START_X 75
#define START_Y 75