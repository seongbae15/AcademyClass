#pragma once
#include "PlayLib.h"
#include "Bitmap.h"
#include <vector>

enum PIECES
{
	PIECES_START = 0,
	PIECES_PAWN1 = 0,
	PIECES_PAWN2,
	PIECES_PAWN3,
	PIECES_PAWN4,
	PIECES_PAWN5,
	PIECES_PAWN6,
	PIECES_PAWN7,
	PIECES_PAWN8,
	PIECES_KNIGHT1,
	PIECES_KNIGHT2,
	PIECES_BISHOP1,
	PIECES_BISHOP2,
	PIECES_ROOK1,
	PEICES_ROOK2,
	PIECES_QUEEN,
	PIECES_KING,
	PIECES_SIZE,
};
enum MOVE_DIR
{
	MOVE_DIR_TOP = 1
};

struct Position
{
	int iX;
	int iY;
};

class Piece
{
protected:
	bool m_bLive;
	Bitmap m_pieceBitmap;
	SIZE m_sizePieceImg;

	Position m_stPos;
	Position m_stLastPos;
	RECT m_rectPiece;

	std::vector<Position> m_vecPossibleMovePos;
	bool m_bFirstMove;

public:
	virtual void InitPiece(HWND hWnd, int Player) = 0;
	virtual void SetInitPos(int Player,int nth)=0;
	void DrawPiece(HDC hdc);
	void Move(POINT mousePt);
	void Drop(POINT mousePt,bool move_state = true);
	void SetImgRect();
	virtual void ShowMove(int player) = 0;
	void ReleaseShowMove();
	inline RECT GetPieceRect()
	{
		return m_rectPiece;
	}
	//virtual void MovePiece() = 0;
};

class Pawn : public Piece
{
private:

public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player,int nth);
	void ShowMove(int player);
};

class Knight : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void ShowMove(int player) {};
};

class Bishop : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void ShowMove(int player) {};
};

class Rook : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void ShowMove(int player) {};
};

class Queen : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void ShowMove(int player) {};
};

class King : public Piece
{
private:
public:
	void InitPiece(HWND hWnd, int Player);
	void SetInitPos(int Player, int nth);
	void ShowMove(int player) {};
};