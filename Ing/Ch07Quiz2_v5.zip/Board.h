#pragma once
#include "Bitmap.h"
#include "PlayLib.h"

class Board
{
private:
	Bitmap m_BoardBitmap[2];
	SIZE m_ImgSize;
public:
	void InitBoard(HWND hWnd);
	void DrawRect(HDC hdc, int x, int y, int width, int height);
	void DrawBoard(HDC hdc);
	void DrawOutBox(HDC hdc);
	void DrawSideText(HDC hdc);
};

