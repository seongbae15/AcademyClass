#pragma once
#include "PlayLib.h"
#include "Piece.h"

class Player
{
private:
	Piece *m_Piece[PIECES_SIZE];
	int m_iSelectedMoveDir;
public:
	void InitPlayer(HWND hWnd, int Player);
	void DrawAllPiece(HDC hdc);
	void MovePiece(int index, POINT mousePt);
	void DropPiece(int index, POINT mousePt, bool move_state = true, int Player = WHITE);
	std::vector<RECT> CheckPlayerPieceMove(int index, POINT mousePt);
	void DiePiece(int index);
	inline RECT GetPiecePosition(int index)
	{
		return m_Piece[index]->GetPieceRect();
	}
	inline std::string GetSelectedType(int index)
	{
		return m_Piece[index]->GetPiecetype();
	}
	inline int GetSelectiedDirection()
	{
		return m_iSelectedMoveDir;
	}
	inline std::vector<RECT>* GetAllMove(int index)
	{
		return m_Piece[index]->GetPossibleMoveAll();
	}
};