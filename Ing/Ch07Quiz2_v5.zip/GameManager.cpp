#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_board.InitBoard(hWnd);
	m_player[WHITE].InitPlayer(hWnd,WHITE);
	m_player[BLACK].InitPlayer(hWnd,BLACK);
}

void GameManager::DrawChessBoard(HDC hdc)
{
	m_board.DrawBoard(hdc);
}

void GameManager::DrawPlayerPiece(HDC hdc)
{
	m_player[WHITE].DrawAllPiece(hdc);
	m_player[BLACK].DrawAllPiece(hdc);
}

bool GameManager::SelectPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	
	for (int i = PIECES_START;i < PIECES_SIZE;i++)
	{
		RECT rectPiece = m_player[m_iTurn % 2].GetPiecePosition(i);
		if (PtInRect(&rectPiece, ptMouse))
		{
			m_iSelectPieceNum = i;
			InvalidateRect(hWnd, &rectPiece, true);
			return true;
		}
	}
	return false;
}

void GameManager::MovePlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	RECT rectPiece = m_player[m_iTurn % 2].GetPiecePosition(m_iSelectPieceNum);
	m_player[m_iTurn % 2].MovePiece(m_iSelectPieceNum, ptMouse);
	InvalidateRect(hWnd, &rectPiece, true);
}

bool GameManager::CheckCheck()
{
	bool bCheckState = false;
	bool bCheckOwn = false;

	std::vector<RECT>* pTmpRECT = m_player[m_iTurn % 2].GetAllMove(m_iSelectPieceNum);
	for (int i = 0; i < 8; i++)
	{
		int iSize = pTmpRECT[i].size();
		bCheckOwn = false;
		for (int j = 0; j < iSize; j++)
		{
			POINT pointTmp = { pTmpRECT[i][j].left, pTmpRECT[i][j].top };
			//ŷ�� ã�����, ���� �� ��� �ٸ� ���� ��ġ�� �ʴ��� Ȯ��
			//���� ��
			for (int k = PIECES_START; k < PIECES_SIZE; k++)
			{
				RECT rectPiece = m_player[m_iTurn % 2].GetPiecePosition(k);
				if (PtInRect(&rectPiece, pointTmp))
				{
					//�ش� ���� �˻�X
					//���� �������� �Ѿ��
					bCheckOwn = true;
					break;
				}
			}
			//ŷ�� ã�����, ���� �� ��� �ٸ� ���� ��ġ�� �ʴ��� Ȯ��
			//��� ��
			if (bCheckOwn == false)
			{
				for (int k = PIECES_START; k < PIECES_SIZE; k++)
				{
					RECT rectPiece = m_player[(m_iTurn+1) % 2].GetPiecePosition(k);
					if (PtInRect(&rectPiece, pointTmp))
					{
						//��ġ�� ���, ŷ���� Ȯ��
						//ŷ�̸� üũ, ����
						if (m_player[(m_iTurn + 1) % 2].GetSelectedType(k) == "King")
						{
							bCheckState = true;
							return bCheckState;
						}
						else
						{
							bCheckOwn = true;
							break;
						}
					}
				}
			}
			if (bCheckOwn == true)
				break;
		}
	}
	return bCheckState;
}
bool GameManager::CheckCheckMate()
{
	return false;
}

void GameManager::DropPlayerPiece(HWND hWnd, LPARAM lParam)
{
	POINT ptMouse;
	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);

	bool bCheckPos = true;
	bCheckPos = CheckDropPossible(ptMouse);
	if (bCheckPos)
	{
		m_player[m_iTurn % 2].DropPiece(m_iSelectPieceNum, ptMouse, bCheckPos, m_iTurn % 2);
		//üũ,üũ����Ʈ Ȯ��
		if (CheckCheck())
		{
			if (CheckCheckMate())
			{
				//üũ ����Ʈ, �޽��� �ڽ� �߻�
			}
			else
			{
				//üũ �޽��� �ڽ� �߻�

			}
		}

		m_iTurn++;
	}
	else
		m_player[m_iTurn % 2].DropPiece(m_iSelectPieceNum, ptMouse, bCheckPos, m_iTurn % 2);
	InvalidateRect(hWnd, NULL, true);
}

bool GameManager::CheckDropPossible(POINT pos)
{
	bool bCheckPos = true;
	std::vector<RECT> checkRect = m_player[m_iTurn % 2].CheckPlayerPieceMove(m_iSelectPieceNum, pos);
	if (checkRect.size() == 0)
		bCheckPos = false;
	else
	{
		int iCount = checkRect.size();
		for (int i = 0; i < iCount; i++)
		{
			// �ڱ⸻ ��ġ �˻�
			for (int j = 0; j < PIECES_SIZE; j++)
			{
				if (j == m_iSelectPieceNum)
					continue;
				RECT tmpRect = m_player[m_iTurn % 2].GetPiecePosition(j);
				if (checkRect[i].top == tmpRect.top && checkRect[i].left == tmpRect.left)
				{
					bCheckPos = false;
					return bCheckPos;
				}
			}
			// ��븻 ��ġ �˻�
			for (int k = 0; k < PIECES_SIZE; k++)
			{
				RECT tmpRect2 = m_player[(m_iTurn+1) % 2].GetPiecePosition(k);
				if (checkRect[i].top == tmpRect2.top && checkRect[i].left == tmpRect2.left)
				{
					if (PtInRect(&checkRect[i], pos))
					{
						//���� ���, ���� ��Ģ ���ϱ�
						if (m_iSelectPieceNum <= PIECES_PAWN8)
						{
							if (m_iTurn % 2 == WHITE)
							{
								if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_TOP)
									bCheckPos = false;
								else
									bCheckPos = true;
							}
							else if (m_iTurn % 2 == BLACK)
							{
								if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_DOWN)
									bCheckPos = false;
								else
									bCheckPos = true;
							}
						}
						else
							bCheckPos = true;
						if (bCheckPos == true)
						{
							m_player[(m_iTurn + 1) % 2].DiePiece(k);
						}
						return bCheckPos;
					}
					bCheckPos = false;
					return bCheckPos;
				}
			}
			//�� ���� �� ��,
			if (PtInRect(&checkRect[i], pos))
			{
				//���� ���, ���� ��Ģ ���ϱ�
				if (m_iSelectPieceNum <= PIECES_PAWN8)
				{
					if (m_iTurn % 2 == WHITE)
					{
						if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_TOP)
							bCheckPos = true;
						else
							bCheckPos = false;
					}
					else if (m_iTurn % 2 == BLACK)
					{
						if (m_player[m_iTurn % 2].GetSelectiedDirection() == MOVE_DIR_DOWN)
							bCheckPos = true;
						else
							bCheckPos =  false;
					}
				}
				else
					bCheckPos = true;
				return bCheckPos;
			}
		}
	}
	return bCheckPos;
}