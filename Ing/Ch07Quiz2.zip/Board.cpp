#include "Board.h"

void Board::InitBoard(HWND hWnd)
{
	HDC hdc = GetDC(hWnd);
}
