#pragma once
#include"PlayLib.h"
#include "Bitmap.h"

class Board
{
private:
	Bitmap m_BoardBitmap;
public:
	void InitBoard(HWND hWnd);
};

