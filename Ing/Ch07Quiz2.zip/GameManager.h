#pragma once
#include "PlayLib.h"
#include "Board.h"
#include "Player.h"
#include "Bitmap.h"
class GameManager
{
private:
	Board m_board;
	Player m_player[2];
	Bitmap m_bitmap;
public:
	void Init(HWND hWnd);
	void DrawBoard();
	void DrawPlayerPiece();
};

