#pragma once
class Bitmap
{
};

