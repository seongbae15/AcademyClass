#pragma once
#include <Windows.h>
#define IMG_SIZE 125
#define WINDOW_WIDTH 125*9
#define WINDOW_HEIGHT 125*9

#define WHITE 0
#define BLACK 1
