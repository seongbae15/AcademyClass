#pragma once
class Piece
{
};

