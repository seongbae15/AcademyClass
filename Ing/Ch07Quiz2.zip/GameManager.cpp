#include "GameManager.h"

void GameManager::Init(HWND hWnd)
{
	m_board.InitBoard(hWnd);
}