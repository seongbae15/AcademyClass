#pragma once
#include <Windows.h>
#define IMG_SIZE 125
#define WINDOW_WIDTH 125*9
#define WINDOW_HEIGHT 125*9
#define IMG_RATE 0.6f

#define ROW 8
#define COL 8

#define WHITE 0
#define BLACK 1

#define START_X 75
#define START_Y 75

#define DIR_COUNT 8

#define INIT_PAWN_COUNT 8
#define INIT_KBR_COUNT 2

#define PAWN_DROP_NONE 0
#define PAWN_DROP_CATCH 1

#define GAME_END_NONE -1
#define GAME_END_CHECK 0
#define GAME_END_CHECKMATE 1

#define KING 15

#define SELF 0
#define OTHER 1

#define CHECK_DROP_GEN 0
#define CHECK_DROP_CM 1

#define DROP_FALSE -1
#define DROP_CATCH 1
#define DROP_NO_CATCH 0